# Librero 2.2 — iOS

Proyecto nativo en SwiftUI, SceneKit, UIKit y PencilKit. iOS 17 o posterior.

## Actualizar desde GitHub

El ZIP de entrega mantiene el nombre Carpetas-iOS.zip para que funcione con el
workflow que ya configuraste. La aplicación instalada se llama Librero.

1. Reemplaza Carpetas-iOS.zip en la raíz de tu repositorio.
2. Abre Actions y ejecuta el workflow que ya usabas para compilar Carpetas.
3. Descarga el artefacto e instala la nueva IPA mediante SideStore.

El proyecto conserva pe.eduardo.carpetas como identificador y biblioteca.json
como archivo de datos, para poder actualizar la aplicación instalada.
El nombre del esquema de compilación sigue siendo Carpetas.
Dentro del paquete también está .github/workflows/build-ios.yml por si lo necesitas.

Si tu repositorio contiene además las fuentes descomprimidas de una versión
anterior, reemplázalas también. El workflow da prioridad a project.yml existente
en el repositorio antes de descomprimir el ZIP.

## Gestos del librero

- Toca un libro para acercarlo y abrirlo con una animación de cubierta.
- Mantén pulsado un libro o adorno durante un instante y arrastra para colocarlo.
- Gira con dos dedos. Los libros pueden quedar inclinados o acostados.
- Pellizca un adorno para cambiar su tamaño.
- Arrastra sobre la madera para recorrer verticalmente los estantes.
- Los dos botones superiores permiten añadir elementos y abrir opciones.
- La galería incluye busto de mármol modelado, flores, boj, hojas, jarrón, marco,
  esfera de metal y velas. Son modelos procedurales, con geometría y materiales
  locales. El paquete no depende de descargas de modelos al abrir la aplicación.
- Los libros y adornos conservan posiciones y ángulos estables al soltar.
  El asentamiento está controlado por la colocación sobre el estante, para evitar
  que una simulación de gravedad desordene el resto de la biblioteca.
  La extracción y la apertura usan una animación guiada.
- La escena, cámara, luces y geometría de los objetos se conservan al mover.
  Solo cambian las transformaciones del elemento manipulado.
- La altura de los adornos se guarda junto con su estante, posición, giro y escala.

## Papel y cubierta

- Toca un espacio vacío del papel para crear una caja de texto y escribir.
- El botón de tipografía cambia fuente, tamaño y tinta del texto seleccionado.
- El lápiz activa PencilKit con su paleta nativa. Vuelve a tocarlo para escribir.
- Añade una foto desde el botón de imagen. Arrástrala, pellizca para redimensionar
  y gira con dos dedos. El menú de adornos permite borrar la selección.
- Los textos también admiten giro, tamaño y movimiento con dos dedos.
- El papel mide 700 × 1000 puntos locales. Sus elementos conservan esas coordenadas.
  El teclado añade espacio de desplazamiento al contenedor y desplaza el libro
  completo para mostrar la escritura. Las imágenes no se reacomodan con el teclado.
- El libro tiene dos hojas planas por apertura. Las flechas cambian el foco de
  izquierda a derecha, y después animan el cambio de apertura hacia la siguiente
  hoja izquierda. También puedes mover y ampliar el libro con los dedos.
- La cuadrícula superior abre las miniaturas. Mantén una miniatura para reordenarla.
- El menú superior permite editar portada, lomo, encuadernación y papel.
- Portada y lomo usan las mismas herramientas de texto, dibujos y fotos.
  El lomo se edita en un lienzo ampliado y se adapta al ancho físico al renderizar.
- Altura y grosor del libro se ajustan en Encuadernación.
- Los cambios se guardan al escribir o terminar un gesto o trazo.
- Las fechas de los registros antiguos se conservan en el respaldo y se omiten
  en la interfaz. El título y texto antiguo se convierten en cajas de texto al editar.

## Datos

La actualización abre los libros de la versión 2.0 con campos nuevos opcionales.
La importación permite restaurar los respaldos JSON de Carpetas para Android
o los de iOS. Se pide confirmación antes de sustituir la biblioteca actual.
Las fotos, los textos libres y los dibujos se incluyen en el respaldo exportado.

## Verificación

Revisión de sintaxis Swift, recursos, versión, compatibilidad de los campos
nuevos y estructura del ZIP realizadas en Linux. La compilación con Xcode y
las pruebas visuales y de gestos en iPhone quedan pendientes de ejecutar en
GitHub o en un Mac. El realismo y el comportamiento de la escena deben
comprobarse en un dispositivo iOS.
