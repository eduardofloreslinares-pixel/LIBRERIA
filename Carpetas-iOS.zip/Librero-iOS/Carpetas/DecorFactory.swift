import SceneKit
import UIKit

enum DecorFactory {
    static func make(_ kind: String, color: String) -> SCNNode {
        let root = SCNNode()
        let ceramic = LibraryMaterials.material("ceramic", color: color)
        let marble = LibraryMaterials.material("stone", color: "#E9E4DA")
        marble.roughness.contents = 0.45
        let green = LibraryMaterials.material("leaf", color: "#38533B")
        func add(_ geometry: SCNGeometry, _ material: SCNMaterial, _ position: SCNVector3,
                 _ scale: SCNVector3 = SCNVector3(1, 1, 1)) -> SCNNode {
            geometry.materials = [material]
            let node = SCNNode(geometry: geometry)
            node.position = position; node.scale = scale
            root.addChildNode(node)
            return node
        }
        if kind == "bust" {
            let stone = color == "#56705B" ? marble : LibraryMaterials.material("stone", color: color)
            _ = add(SCNCylinder(radius: 0.28, height: 0.1), stone, SCNVector3(0, 0.05, 0))
            _ = add(SCNCylinder(radius: 0.13, height: 0.2), stone, SCNVector3(0, 0.19, 0))
            _ = add(SCNSphere(radius: 0.34), stone, SCNVector3(0, 0.44, 0), SCNVector3(1.2, 0.75, 0.58))
            _ = add(SCNCylinder(radius: 0.105, height: 0.22), stone, SCNVector3(0, 0.7, 0))
            _ = add(SCNSphere(radius: 0.235), stone, SCNVector3(0, 0.97, 0), SCNVector3(0.78, 1.13, 0.87))
            _ = add(SCNSphere(radius: 0.12), stone, SCNVector3(0, 0.83, 0.06), SCNVector3(1, 0.63, 0.9))
            let nose = add(SCNPyramid(width: 0.065, height: 0.15, length: 0.1), stone, SCNVector3(0, 0.96, 0.18))
            nose.eulerAngles.x = .pi / 2
            for x: Float in [-0.081, 0.081] {
                _ = add(SCNSphere(radius: 0.032), stone, SCNVector3(x, 1.015, 0.169), SCNVector3(1, 0.55, 0.3))
                let brow = add(SCNCapsule(capRadius: 0.014, height: 0.09), stone, SCNVector3(x, 1.047, 0.16))
                brow.eulerAngles.z = .pi / 2
            }
            _ = add(SCNSphere(radius: 0.036), stone, SCNVector3(0, 0.884, 0.175), SCNVector3(1.35, 0.24, 0.42))
            for x: Float in [-0.18, 0.18] {
                _ = add(SCNSphere(radius: 0.05), stone, SCNVector3(x, 0.97, 0), SCNVector3(0.45, 1.2, 0.65))
            }
            for i in 0..<65 {
                let angle = Double(i) * 2.39996
                let ring = Double(i % 8) / 8
                let y = Float(1.11 + ring * 0.12)
                let radius = Float(0.18 * sqrt(max(0.1, 1 - ring * ring)))
                _ = add(SCNSphere(radius: 0.035 + CGFloat(i % 3) * 0.004), stone,
                        SCNVector3(Float(sin(angle)) * radius, y, Float(cos(angle)) * radius - 0.025))
            }
        } else if kind == "frame" {
            _ = add(SCNBox(width: 0.85, height: 1, length: 0.08, chamferRadius: 0.025),
                    LibraryMaterials.material("wood", color: "#8B6B3C"), SCNVector3(0, 0.5, 0))
            _ = add(SCNBox(width: 0.7, height: 0.85, length: 0.01, chamferRadius: 0), ceramic, SCNVector3(0, 0.5, 0.052))
        } else if kind == "sphere" {
            let brass = LibraryMaterials.material("metal", color: "#BA9855")
            brass.metalness.contents = 0.85; brass.roughness.contents = 0.3
            _ = add(SCNSphere(radius: 0.35), brass, SCNVector3(0, 0.35, 0))
        } else if kind == "candles" {
            for i in 0..<3 {
                let x = Float(i - 1) * 0.25
                let height = 0.48 + CGFloat(i) * 0.16
                _ = add(SCNCylinder(radius: 0.09, height: height),
                        LibraryMaterials.material("wax", color: "#E7DBBD"), SCNVector3(x, Float(height / 2), 0))
                let flame = SCNSphere(radius: 0.035)
                let fire = SCNMaterial()
                fire.diffuse.contents = UIColor.orange
                fire.emission.contents = UIColor(red: 1, green: 0.57, blue: 0.13, alpha: 1)
                _ = add(flame, fire, SCNVector3(x, Float(height) + 0.045, 0), SCNVector3(0.65, 1.8, 0.65))
            }
        } else {
            let profile: [(Double, Double)] = kind == "vase" || kind == "flowers" ?
                [(0, 0.17), (0.05, 0.2), (0.2, 0.28), (0.42, 0.25), (0.58, 0.1), (0.72, 0.1)] :
                [(0, 0.15), (0.04, 0.18), (0.48, 0.25), (0.51, 0.27), (0.54, 0.25)]
            _ = add(lathe(profile), ceramic, SCNVector3Zero)
            if kind == "topiary" {
                _ = add(SCNCylinder(radius: 0.025, height: 0.4), LibraryMaterials.material("wood", color: "#66523B"), SCNVector3(0, 0.69, 0))
                for i in 0..<110 {
                    let t = Double(i) / 110
                    let a = Double(i) * 2.39996
                    let y = 1 - 2 * t
                    let r = sqrt(max(0, 1 - y * y))
                    _ = add(SCNSphere(radius: 0.065), green,
                            SCNVector3(Float(cos(a) * r * 0.29), Float(0.99 + y * 0.29), Float(sin(a) * r * 0.29)))
                }
            } else if kind == "flowers" || kind == "plant" {
                let flowers = kind == "flowers"
                for i in 0..<(flowers ? 9 : 11) {
                    let angle = Double(i) * 2.39996
                    let x = Float(sin(angle) * 0.26), z = Float(cos(angle) * 0.19)
                    let y: Float = 0.95 + Float(i % 3) * 0.12
                    let stem = add(SCNCylinder(radius: 0.008, height: CGFloat(y - 0.45)), green, SCNVector3(x / 2, (y + 0.45) / 2, z / 2))
                    stem.eulerAngles.z = -x * 0.7
                    if flowers {
                        let petal = LibraryMaterials.material("silk", color: i % 2 == 0 ? "#EAD9C7" : "#B77E80")
                        for j in 0..<6 {
                            let a = Double(j) * .pi / 3
                            let node = add(SCNSphere(radius: 0.06), petal,
                                           SCNVector3(x + Float(sin(a) * 0.065), y, z + Float(cos(a) * 0.065)),
                                           SCNVector3(1, 0.38, 1.45))
                            node.eulerAngles.y = Float(a)
                        }
                        _ = add(SCNSphere(radius: 0.027), LibraryMaterials.material("pollen", color: "#BBA04D"), SCNVector3(x, y + 0.012, z))
                    } else {
                        let leaf = add(SCNSphere(radius: 0.19), green, SCNVector3(x, y - 0.1, z), SCNVector3(0.55, 1.7, 0.12))
                        leaf.eulerAngles.z = -x * 2
                        leaf.eulerAngles.y = Float(angle)
                    }
                }
            }
        }
        return root
    }

    static func lathe(_ profile: [(Double, Double)]) -> SCNGeometry {
        let segments = 48
        var vertices: [SCNVector3] = []
        var normals: [SCNVector3] = []
        var indices: [UInt32] = []
        for (y, radius) in profile {
            for segment in 0...segments {
                let a = Double(segment) * 2 * .pi / Double(segments)
                vertices.append(SCNVector3(Float(radius * cos(a)), Float(y), Float(radius * sin(a))))
                normals.append(SCNVector3(Float(cos(a)), 0.15, Float(sin(a))))
            }
        }
        for row in 0..<(profile.count - 1) {
            for segment in 0..<segments {
                let a = UInt32(row * (segments + 1) + segment), b = a + UInt32(segments + 1)
                indices += [a, b, a + 1, a + 1, b, b + 1]
            }
        }
        let geometry = SCNGeometry(sources: [SCNGeometrySource(vertices: vertices), SCNGeometrySource(normals: normals)],
                                   elements: [SCNGeometryElement(indices: indices, primitiveType: .triangles)])
        return geometry
    }
    static func preview(_ kind: String) -> SCNScene {
        let scene = SCNScene()
        scene.background.contents = UIColor.clear
        scene.rootNode.addChildNode(make(kind, color: kind == "bust" ? "#E9E4DA" : "#61725A"))
        let camera = SCNNode()
        camera.camera = SCNCamera()
        camera.position = SCNVector3(0, 0.68, 2.6)
        scene.rootNode.addChildNode(camera)
        return scene
    }
}
