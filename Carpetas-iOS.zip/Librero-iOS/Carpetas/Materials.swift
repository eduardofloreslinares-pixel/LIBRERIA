import UIKit
import SceneKit
import PencilKit

enum LibraryMaterials {
    static var cache: [String: UIImage] = [:]

    static func texture(_ kind: String, color: String) -> UIImage {
        let key = kind + color
        if let image = cache[key] { return image }
        let size = CGSize(width: 512, height: 512)
        let image = UIGraphicsImageRenderer(size: size).image { renderer in
            let ctx = renderer.cgContext
            UIColor(hex: color).setFill()
            ctx.fill(CGRect(origin: .zero, size: size))
            var seed: UInt64 = 947381
            func random() -> CGFloat {
                seed = seed &* 6364136223846793005 &+ 1
                return CGFloat((seed >> 33) % 10000) / 10000
            }
            if kind == "wood" {
                for y in 0..<512 {
                    let offset = random() * 15
                    ctx.setStrokeColor(UIColor(white: random() > 0.5 ? 0.95 : 0.05, alpha: 0.04 + random() * 0.1).cgColor)
                    ctx.setLineWidth(0.4 + random() * 1.5)
                    ctx.move(to: CGPoint(x: 0, y: CGFloat(y)))
                    ctx.addCurve(to: CGPoint(x: 512, y: CGFloat(y) + offset),
                                 control1: CGPoint(x: 180, y: CGFloat(y) - offset),
                                 control2: CGPoint(x: 340, y: CGFloat(y) + offset))
                    ctx.strokePath()
                }
            } else {
                for _ in 0..<26000 {
                    ctx.setFillColor(UIColor(white: random() > 0.5 ? 1 : 0, alpha: kind == "leather" ? 0.12 : 0.055).cgColor)
                    let x = random() * 512, y = random() * 512
                    ctx.fillEllipse(in: CGRect(x: x, y: y, width: 0.6 + random() * 1.7, height: 0.8))
                }
                if kind == "linen" {
                    ctx.setStrokeColor(UIColor(white: 0.9, alpha: 0.13).cgColor)
                    ctx.setLineWidth(0.5)
                    for p in stride(from: 0, to: 512, by: 3) {
                        ctx.move(to: CGPoint(x: CGFloat(p), y: 0)); ctx.addLine(to: CGPoint(x: CGFloat(p), y: 512))
                        ctx.move(to: CGPoint(x: 0, y: CGFloat(p))); ctx.addLine(to: CGPoint(x: 512, y: CGFloat(p)))
                    }
                    ctx.strokePath()
                }
            }
        }
        cache[key] = image
        return image
    }

    static func material(_ kind: String, color: String) -> SCNMaterial {
        let result = SCNMaterial()
        result.diffuse.contents = texture(kind, color: color)
        result.lightingModel = .physicallyBased
        result.roughness.contents = kind == "leather" ? 0.62 : 0.82
        result.metalness.contents = 0
        return result
    }

    static func cover(_ book: LibraryBook, spine: Bool) -> UIImage {
        let size = spine ? CGSize(width: 200, height: 900) : CGSize(width: 650, height: 900)
        return UIGraphicsImageRenderer(size: size).image { renderer in
            let bounds = CGRect(origin: .zero, size: size)
            texture(book.material, color: book.color).draw(in: bounds)
            let photo = spine ? book.spinePhoto : book.coverPhoto
            if let photo, let image = UIImage(data: photo) {
                let factor = max(size.width / image.size.width, size.height / image.size.height)
                let width = image.size.width * factor, height = image.size.height * factor
                image.draw(in: CGRect(x: (size.width - width) / 2, y: (size.height - height) / 2, width: width, height: height), blendMode: .normal, alpha: 0.83)
            }
            let ink = UIColor(hex: book.lettering)
            let ctx = renderer.cgContext
            ctx.setStrokeColor(ink.withAlphaComponent(0.75).cgColor)
            if book.ornament != "plain" {
                ctx.setLineWidth(2)
                ctx.stroke(bounds.insetBy(dx: spine ? 18 : 36, dy: 46))
                ctx.stroke(bounds.insetBy(dx: spine ? 24 : 43, dy: 53))
            }
            if spine {
                for y in [100, 130, 760, 790] {
                    ctx.setLineWidth(5)
                    ctx.move(to: CGPoint(x: 12, y: CGFloat(y))); ctx.addLine(to: CGPoint(x: size.width - 12, y: CGFloat(y)))
                    ctx.strokePath()
                }
            }
            let design = spine ? book.spineDesign : book.coverDesign
            let text = design == nil ? (spine && !book.spine.isEmpty ? book.spine : book.title) : ""
            let paragraph = NSMutableParagraphStyle()
            paragraph.alignment = .center
            let font = UIFont(name: "Baskerville", size: spine ? 40 : 64) ?? .systemFont(ofSize: spine ? 40 : 64)
            (text as NSString).draw(in: CGRect(x: spine ? 30 : 65, y: 220, width: size.width - (spine ? 60 : 130), height: 380),
                                    withAttributes: [.font: font, .foregroundColor: ink, .paragraphStyle: paragraph])
            if !spine && design == nil {
                (book.author as NSString).draw(in: CGRect(x: 55, y: 680, width: size.width - 110, height: 100),
                                             withAttributes: [.font: UIFont.italicSystemFont(ofSize: 24), .foregroundColor: ink, .paragraphStyle: paragraph])
                if book.ornament == "star" {
                    ("✦" as NSString).draw(in: CGRect(x: 270, y: 580, width: 110, height: 80),
                                          withAttributes: [.font: UIFont.systemFont(ofSize: 60), .foregroundColor: ink])
                }
            }
            if let design { drawPageContent(design, in: bounds, context: ctx) }
        }
    }

    static func pagePreview(_ page: BookPage) -> UIImage {
        let size = CGSize(width: 350, height: 500)
        return UIGraphicsImageRenderer(size: size).image { renderer in
            let bounds = CGRect(origin: .zero, size: size)
            texture("paper", color: "#F2E8D2").draw(in: bounds)
            var content = page
            if content.fragments == nil {
                content.fragments = []
                if !page.title.isEmpty {
                    var title = TextFragment()
                    title.text = page.title; title.y = 0.09; title.size = 40
                    content.fragments?.append(title)
                }
                if !page.text.isEmpty {
                    var text = TextFragment()
                    text.text = page.text; text.y = 0.23
                    content.fragments?.append(text)
                }
            }
            drawPageContent(content, in: bounds, context: renderer.cgContext)
        }
    }

    static func drawPageContent(_ page: BookPage, in bounds: CGRect, context ctx: CGContext) {
        if let data = page.drawing, let drawing = try? PKDrawing(data: data) {
            drawing.image(from: CGRect(x: 0, y: 0, width: 700, height: 1000), scale: 1).draw(in: bounds)
        }
        for fragment in page.fragments ?? [] {
            ctx.saveGState()
            let origin = CGPoint(x: fragment.x * bounds.width, y: fragment.y * bounds.height)
            ctx.translateBy(x: origin.x, y: origin.y)
            ctx.rotate(by: fragment.rotation * .pi / 180)
            let font = UIFont(name: fragment.font, size: fragment.size * bounds.width / 700) ??
                .systemFont(ofSize: fragment.size * bounds.width / 700)
            (fragment.text as NSString).draw(in: CGRect(x: 0, y: 0, width: fragment.width * bounds.width, height: bounds.height),
                                           withAttributes: [.font: font, .foregroundColor: UIColor(hex: fragment.color)])
            ctx.restoreGState()
        }
        for object in page.objects {
            ctx.saveGState()
            ctx.translateBy(x: object.x * bounds.width, y: object.y * bounds.height)
            ctx.rotate(by: object.rotation * .pi / 180)
            let width = object.width * bounds.width
            if let data = object.image, let image = UIImage(data: data) {
                let height = min(bounds.height * 0.8, width * image.size.height / max(1, image.size.width))
                UIColor.white.setFill()
                ctx.fill(CGRect(x: -width / 2 - 2, y: -height / 2 - 2, width: width + 4, height: height + 4))
                image.draw(in: CGRect(x: -width / 2, y: -height / 2, width: width, height: height))
            } else {
                (object.symbol as NSString).draw(at: CGPoint(x: -width / 2, y: -width / 2),
                                               withAttributes: [.font: UIFont.systemFont(ofSize: width), .foregroundColor: UIColor.brown])
            }
            ctx.restoreGState()
        }
    }
}

