import SwiftUI
import PhotosUI

struct BookReader: View {
    let bookID: UUID
    @EnvironmentObject private var store: LibraryStore
    @Environment(\.dismiss) private var dismiss
    @State private var index = 0
    @State private var commands = PaperCommands()
    @State private var photo: PhotosPickerItem?
    @State private var loading = false
    @State private var showIndex = false
    @State private var binding = false
    @State private var cover = false
    @State private var deleting = false
    private var book: LibraryBook? { store.book(bookID) }

    var body: some View {
        ZStack {
            if let book {
                BookDesk(pages: book.pages, index: min(index, book.pages.count - 1), commands: commands,
                         onChange: { store.updatePage(bookID: bookID, page: $0) },
                         onIndex: { index = $0 })
                    .ignoresSafeArea(.keyboard)
                    .safeAreaInset(edge: .top, spacing: 0) { topBar }
                    .safeAreaInset(edge: .bottom, spacing: 0) {
                        HStack(spacing: 22) {
                            Button { changePage(-1) } label: { Image(systemName: "chevron.left") }.disabled(index == 0)
                            Spacer(minLength: 0)
                            PaperToolbar(commands: $commands, photo: $photo, loading: loading)
                            Spacer(minLength: 0)
                            Button { changePage(1) } label: { Image(systemName: "chevron.right") }
                        }
                        .padding(.horizontal, 18).padding(.vertical, 13)
                        .background(.regularMaterial, in: Capsule())
                        .padding(.horizontal, 16).padding(.bottom, 8)
                    }
            }
        }
        .ignoresSafeArea(.keyboard)
        .sheet(isPresented: $showIndex) { pageIndex }
        .sheet(isPresented: $binding) { BookCustomizer(bookID: bookID).environmentObject(store) }
        .fullScreenCover(isPresented: $cover) { CoverEditor(bookID: bookID).environmentObject(store) }
        .onChange(of: photo) { _, item in loadPhoto(item) }
        .confirmationDialog("¿Eliminar la página?", isPresented: $deleting, titleVisibility: .visible) {
            Button("Eliminar página", role: .destructive) {
                guard var book, book.pages.count > 1 else { return }
                book.pages.remove(at: min(index, book.pages.count - 1))
                index = min(index, book.pages.count - 1)
                store.update(book)
            }
        }
        .onChange(of: store.state.books.contains(where: { $0.id == bookID })) { _, exists in if !exists { dismiss() } }
        .alert("Librero", isPresented: Binding(get: { store.error != nil }, set: { if !$0 { store.error = nil } })) {
            Button("Aceptar") { store.error = nil }
        } message: { Text(store.error ?? "") }
    }
    private var topBar: some View {
        HStack {
            Button { dismiss() } label: { Image(systemName: "chevron.down") }.accessibilityLabel("Volver al librero")
            Spacer()
            Button { showIndex = true } label: { Image(systemName: "square.grid.2x2") }.accessibilityLabel("Páginas")
            Menu {
                Button("Añadir página", systemImage: "doc.badge.plus") { addPage() }
                Button("Editar cubierta", systemImage: "book.closed") { cover = true }
                Button("Encuadernación", systemImage: "slider.horizontal.3") { binding = true }
                Menu("Papel") {
                    Button("Marfil") { paper("cream") }
                    Button("Blanco") { paper("white") }
                    Button("Azul") { paper("blue") }
                    Button("Rosa") { paper("rose") }
                }
                Button("Eliminar página", role: .destructive) { deleting = true }.disabled((book?.pages.count ?? 0) < 2)
            } label: { Image(systemName: "ellipsis") }
        }
        .padding(.horizontal, 20).padding(.vertical, 12)
        .background(.regularMaterial, in: Capsule()).padding(.horizontal, 16).padding(.top, 8)
    }
    private var pageIndex: some View {
        NavigationStack {
            ScrollView {
                LazyVGrid(columns: [GridItem(.adaptive(minimum: 120))], spacing: 20) {
                    if let book {
                        ForEach(Array(book.pages.enumerated()), id: \.element.id) { pair in
                            Button {
                                index = pair.offset; showIndex = false
                            } label: {
                                VStack(spacing: 7) {
                                    Image(uiImage: LibraryMaterials.pagePreview(pair.element))
                                        .resizable().scaledToFit()
                                        .shadow(color: .black.opacity(0.15), radius: 4, y: 3)
                                    Text("\(pair.offset + 1)").font(.caption).foregroundStyle(.secondary)
                                }
                            }
                            .contextMenu {
                                Button("Mover antes") { movePage(pair.offset, by: -1) }.disabled(pair.offset == 0)
                                Button("Mover después") { movePage(pair.offset, by: 1) }.disabled(pair.offset == book.pages.count - 1)
                            }
                        }
                    }
                    Button { addPage(); showIndex = false } label: {
                        Image(systemName: "plus").frame(width: 100, height: 150)
                            .background(.quaternary, in: RoundedRectangle(cornerRadius: 6))
                    }
                }.padding(24)
            }.navigationTitle("Páginas").navigationBarTitleDisplayMode(.inline)
        }
    }
    private func addPage() {
        guard var book else { return }
        let position = min(index + 1, book.pages.count)
        book.pages.insert(BookPage(), at: position)
        store.update(book); index = position
    }
    private func changePage(_ delta: Int) {
        guard let book else { return }
        if index + delta >= book.pages.count { addPage() }
        else { index = max(0, index + delta) }
    }
    private func movePage(_ from: Int, by delta: Int) {
        guard var book, book.pages.indices.contains(from + delta) else { return }
        book.pages.swapAt(from, from + delta)
        store.update(book)
        index = from + delta
    }
    private func paper(_ value: String) {
        guard let book, book.pages.indices.contains(index) else { return }
        var page = book.pages[index]
        page.paper = value
        store.updatePage(bookID: bookID, page: page)
    }
    private func loadPhoto(_ item: PhotosPickerItem?) {
        guard let item else { return }
        loading = true
        Task { @MainActor in
            defer { loading = false; photo = nil }
            do {
                guard let data = try await item.loadTransferable(type: Data.self) else { throw CocoaError(.fileReadUnknown) }
                commands.image = try LibraryStore.photo(data)
                commands.symbol = nil
                commands.actionID = UUID()
            } catch { store.error = "No se pudo cargar la fotografía." }
        }
    }
}

struct PaperToolbar: View {
    @Binding var commands: PaperCommands
    @Binding var photo: PhotosPickerItem?
    var loading: Bool
    var body: some View {
        HStack(spacing: 18) {
            Button {
                commands.tool = commands.tool == .pencil ? .text : .pencil
            } label: {
                Image(systemName: commands.tool == .pencil ? "pencil.tip.crop.circle.fill" : "pencil.tip.crop.circle")
            }.accessibilityLabel("Dibujar")
            .contextMenu {
                Button("Lápiz") { commands.tool = .pencil }
                Button("Borrador") { commands.tool = .eraser }
                Button("Escribir") { commands.tool = .text }
            }
            Menu {
                ForEach(["Baskerville", "Georgia", "HelveticaNeue", "Menlo", "Noteworthy", "SnellRoundhand"], id: \.self) { font in
                    Button(font) { commands.font = font; commands.tool = .text }
                }
                Divider()
                Button("Letra pequeña") { commands.fontSize = 24 }
                Button("Letra mediana") { commands.fontSize = 34 }
                Button("Letra grande") { commands.fontSize = 48 }
                ColorPicker("Tinta", selection: Binding(get: { Color(uiColor: UIColor(hex: commands.ink)) },
                                                       set: { commands.ink = UIColor($0).hex }), supportsOpacity: false)
            } label: { Image(systemName: "textformat") }
            PhotosPicker(selection: $photo, matching: .images) {
                Image(systemName: loading ? "hourglass" : "photo")
            }.disabled(loading)
            Menu {
                ForEach(["✦", "✿", "♡", "❧", "★", "☾"], id: \.self) { symbol in
                    Button(symbol) { commands.symbol = symbol; commands.image = nil; commands.actionID = UUID() }
                }
                Divider()
                Button("Eliminar selección", role: .destructive) { commands.deleteID = UUID() }
            } label: { Image(systemName: "sparkles") }
        }.font(.system(size: 18)).tint(.brown)
    }
}

struct CoverEditor: View {
    let bookID: UUID
    @EnvironmentObject private var store: LibraryStore
    @Environment(\.dismiss) private var dismiss
    @State private var spine = false
    @State private var binding = false
    @State private var commands = PaperCommands()
    @State private var photo: PhotosPickerItem?
    @State private var loading = false

    private var book: LibraryBook? { store.book(bookID) }
    private var design: BookPage {
        guard let book else { return BookPage() }
        if let existing = spine ? book.spineDesign : book.coverDesign { return existing }
        var page = BookPage()
        page.id = bookID
        page.title = spine && !book.spine.isEmpty ? book.spine : book.title
        page.ink = book.lettering
        return page
    }
    private var base: UIImage? {
        guard var book else { return nil }
        book.title = ""; book.spine = ""; book.author = ""
        book.coverDesign = nil; book.spineDesign = nil
        return LibraryMaterials.cover(book, spine: spine)
    }
    var body: some View {
        let editingSpine = spine
        BookDesk(pages: [design], index: 0, commands: commands, cover: base,
                 onChange: { update($0, spine: editingSpine) }, onIndex: { _ in })
            .id(spine)
            .ignoresSafeArea(.keyboard)
            .safeAreaInset(edge: .top, spacing: 0) {
                HStack {
                    Button { dismiss() } label: { Image(systemName: "chevron.down") }
                    Spacer()
                    Picker("Cubierta", selection: $spine) { Text("Portada").tag(false); Text("Lomo").tag(true) }
                        .pickerStyle(.segmented).frame(maxWidth: 230)
                    Spacer()
                    Button { binding = true } label: { Image(systemName: "slider.horizontal.3") }
                }.padding(16).background(.regularMaterial)
            }
            .safeAreaInset(edge: .bottom, spacing: 0) {
                PaperToolbar(commands: $commands, photo: $photo, loading: loading)
                    .padding(18).frame(maxWidth: .infinity).background(.regularMaterial)
            }
            .sheet(isPresented: $binding) { BookCustomizer(bookID: bookID).environmentObject(store) }
            .onChange(of: photo) { _, item in
                guard let item else { return }
                loading = true
                Task { @MainActor in
                    defer { photo = nil; loading = false }
                    do {
                        guard let data = try await item.loadTransferable(type: Data.self) else { throw CocoaError(.fileReadUnknown) }
                        commands.image = try LibraryStore.photo(data); commands.symbol = nil; commands.actionID = UUID()
                    } catch { store.error = "No se pudo cargar la fotografía." }
                }
            }
            .alert("Librero", isPresented: Binding(get: { store.error != nil }, set: { if !$0 { store.error = nil } })) {
                Button("Aceptar") { store.error = nil }
            } message: { Text(store.error ?? "") }
    }
    private func update(_ page: BookPage, spine: Bool) {
        guard var book else { return }
        if spine { book.spineDesign = page } else { book.coverDesign = page }
        store.update(book)
    }
}
