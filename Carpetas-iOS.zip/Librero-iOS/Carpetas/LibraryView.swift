import SwiftUI
import PhotosUI
import UniformTypeIdentifiers
import SceneKit

@main
struct LibreroApp: App {
    @StateObject private var store = LibraryStore()
    var body: some Scene {
        WindowGroup {
            LibraryView().environmentObject(store).preferredColorScheme(.light)
        }
    }
}

private struct Selection: Identifiable { let id: UUID }

struct LibraryView: View {
    @EnvironmentObject private var store: LibraryStore
    @State private var reading: Selection?
    @State private var cover: Selection?
    @State private var decoration: Selection?
    @State private var gallery = false
    @State private var importing = false
    @State private var pendingImport: Data?
    @State private var confirmImport = false
    @State private var exporting = false
    @State private var backup = BackupDocument(data: Data())
    @State private var help = false

    var body: some View {
        BookshelfScene(state: store.state, revision: store.revision,
                       onOpen: { reading = Selection(id: $0) },
                       onMove: { store.place(id: $0, shelf: $1, x: $2, elevation: $3, angle: $4, scale: $5) },
                       onInspect: { decoration = Selection(id: $0) })
            .ignoresSafeArea()
            .overlay(alignment: .top) {
                HStack {
                    Menu {
                        Button("Libro", systemImage: "book.closed") { cover = Selection(id: store.addBook()) }
                        Button("Adorno", systemImage: "leaf") { gallery = true }
                        if store.state.shelves < 8 {
                            Button("Estante", systemImage: "rectangle.split.3x1") { store.state.shelves += 1; store.save() }
                        }
                    } label: { control("plus") }.accessibilityLabel("Añadir")
                    Spacer()
                    Menu {
                        Menu("Madera") {
                            Button("Nogal") { wood("walnut") }
                            Button("Roble") { wood("oak") }
                            Button("Ébano") { wood("ebony") }
                        }
                        Button("Importar biblioteca", systemImage: "square.and.arrow.down") { importing = true }
                        Button("Exportar biblioteca", systemImage: "square.and.arrow.up") {
                            do { backup = BackupDocument(data: try store.export()); exporting = true }
                            catch { store.error = error.localizedDescription }
                        }
                        Button("Gestos", systemImage: "hand.draw") { help = true }
                    } label: { control("ellipsis") }.accessibilityLabel("Opciones")
                }.padding(.horizontal, 18).padding(.top, 8)
            }
            .sheet(isPresented: $gallery) { DecorationGallery().environmentObject(store) }
            .sheet(item: $decoration) { selection in ObjectCustomizer(objectID: selection.id).environmentObject(store) }
            .fullScreenCover(item: $cover) { selection in CoverEditor(bookID: selection.id).environmentObject(store) }
            .fullScreenCover(item: $reading) { selection in BookReader(bookID: selection.id).environmentObject(store) }
            .fileImporter(isPresented: $importing, allowedContentTypes: [.json]) { result in
                do {
                    let url = try result.get()
                    let granted = url.startAccessingSecurityScopedResource()
                    defer { if granted { url.stopAccessingSecurityScopedResource() } }
                    pendingImport = try Data(contentsOf: url); confirmImport = true
                } catch { store.error = "No se pudo leer el respaldo." }
            }
            .confirmationDialog("¿Restaurar esta biblioteca?", isPresented: $confirmImport, titleVisibility: .visible) {
                Button("Restaurar", role: .destructive) {
                    guard let data = pendingImport else { return }
                    do { try store.restore(data) } catch { store.error = "El respaldo no tiene un formato válido." }
                    pendingImport = nil
                }
                Button("Cancelar", role: .cancel) { pendingImport = nil }
            } message: { Text("Se sustituirá la biblioteca actual por el respaldo elegido.") }
            .fileExporter(isPresented: $exporting, document: backup, contentType: .json, defaultFilename: "Librero") { result in
                if case .failure(let error) = result { store.error = error.localizedDescription }
            }
            .alert("Librero", isPresented: Binding(get: { store.error != nil }, set: { if !$0 { store.error = nil } })) {
                Button("Aceptar") { store.error = nil }
            } message: { Text(store.error ?? "") }
            .alert("Gestos", isPresented: $help) {
                Button("Entendido", role: .cancel) {}
            } message: {
                Text("Desliza sobre la madera para recorrer el librero. Mantén pulsado un libro o adorno para colocarlo; gira con dos dedos. Pellizca un adorno para cambiar su tamaño. Un toque abre un libro. Toca el papel para escribir, usa el lápiz para dibujar y arrastra o gira tus fotos.")
            }
    }
    private func control(_ symbol: String) -> some View {
        Image(systemName: symbol).font(.system(size: 17, weight: .medium)).frame(width: 42, height: 42)
            .foregroundStyle(.primary).background(.ultraThinMaterial, in: Circle())
    }
    private func wood(_ value: String) { store.state.wood = value; store.save() }
}

struct BookCustomizer: View {
    let bookID: UUID
    @EnvironmentObject private var store: LibraryStore
    @Environment(\.dismiss) private var dismiss
    @State private var draft = LibraryBook()
    @State private var deleting = false
    var body: some View {
        NavigationStack {
            Form {
                Section {
                    HStack {
                        Spacer()
                        Image(uiImage: LibraryMaterials.cover(draft, spine: false))
                            .resizable().scaledToFit().frame(height: 190).shadow(radius: 6, x: 3, y: 5)
                        Spacer()
                    }.padding(12).listRowBackground(Color.clear)
                }
                Section {
                    TextField("Nombre del libro", text: $draft.title)
                    TextField("Texto del lomo", text: $draft.spine)
                    ColorPicker("Encuadernación", selection: color(\.color), supportsOpacity: false)
                    ColorPicker("Letras", selection: color(\.lettering), supportsOpacity: false)
                    Picker("Material", selection: $draft.material) {
                        Text("Cuero").tag("leather"); Text("Lino").tag("linen"); Text("Papel").tag("paper")
                    }
                    Picker("Grabado", selection: $draft.ornament) {
                        Text("Marco").tag("frame"); Text("Estrella").tag("star"); Text("Liso").tag("plain")
                    }
                }
                Section {
                    LabeledContent("Altura") { Slider(value: $draft.height, in: 1...2.1) }
                    LabeledContent("Grosor") { Slider(value: $draft.thickness, in: 0.22...0.7) }
                }
                Section { Button("Eliminar libro", role: .destructive) { deleting = true } }
            }
            .navigationTitle("Encuadernación").navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancelar") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Guardar") { store.update(draft); dismiss() }.disabled(draft.title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                }
            }
            .onAppear { if let book = store.book(bookID) { draft = book } }
            .confirmationDialog("¿Eliminar el libro y sus páginas?", isPresented: $deleting, titleVisibility: .visible) {
                Button("Eliminar libro", role: .destructive) { store.removeBook(bookID); dismiss() }
            }
        }
    }
    private func color(_ path: WritableKeyPath<LibraryBook, String>) -> Binding<Color> {
        Binding(get: { Color(uiColor: UIColor(hex: draft[keyPath: path])) }, set: { draft[keyPath: path] = UIColor($0).hex })
    }
}

struct DecorationGallery: View {
    @EnvironmentObject private var store: LibraryStore
    @Environment(\.dismiss) private var dismiss
    private let kinds = [("bust", "Busto de mármol"), ("flowers", "Flores"), ("topiary", "Boj"),
                         ("vase", "Cerámica"), ("plant", "Hojas"), ("frame", "Marco"),
                         ("sphere", "Esfera"), ("candles", "Velas")]
    var body: some View {
        NavigationStack {
            ScrollView {
                LazyVGrid(columns: [GridItem(.adaptive(minimum: 140))], spacing: 16) {
                    ForEach(kinds, id: \.0) { kind in
                        Button {
                            var object = ShelfObject()
                            object.kind = kind.0
                            object.color = kind.0 == "bust" ? "#ECE6DA" : "#56705B"
                            store.state.objects.append(object); store.save(); dismiss()
                        } label: {
                            VStack {
                                SceneView(scene: DecorFactory.preview(kind.0), options: [.autoenablesDefaultLighting])
                                    .frame(height: 145).allowsHitTesting(false)
                                Text(kind.1).font(.caption).foregroundStyle(.primary)
                            }
                            .padding(10).background(.quaternary, in: RoundedRectangle(cornerRadius: 18))
                        }
                    }
                }.padding(20)
            }
            .navigationTitle("Adornos").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Cerrar") { dismiss() } } }
        }.presentationDetents([.medium, .large])
    }
}

struct ObjectCustomizer: View {
    let objectID: UUID
    @EnvironmentObject private var store: LibraryStore
    @Environment(\.dismiss) private var dismiss
    var body: some View {
        NavigationStack {
            Form {
                if let index = store.state.objects.firstIndex(where: { $0.id == objectID }) {
                    SceneView(scene: DecorFactory.preview(store.state.objects[index].kind), options: [.autoenablesDefaultLighting])
                        .frame(height: 200).listRowBackground(Color.clear)
                    ColorPicker("Color", selection: Binding(
                        get: { Color(uiColor: UIColor(hex: store.state.objects[index].color)) },
                        set: { store.state.objects[index].color = UIColor($0).hex; store.save() }), supportsOpacity: false)
                    Button("Quitar adorno", role: .destructive) {
                        store.state.objects.removeAll { $0.id == objectID }; store.save(); dismiss()
                    }
                }
            }
            .navigationTitle("Adorno").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Cerrar") { dismiss() } } }
        }.presentationDetents([.medium])
    }
}
