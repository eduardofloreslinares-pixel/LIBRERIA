import SwiftUI
import UIKit
import PencilKit

enum PaperTool: String { case text, pencil, eraser }

@MainActor
final class PaperSurface: UIView, UITextViewDelegate, PKCanvasViewDelegate, UIGestureRecognizerDelegate {
    static let size = CGSize(width: 700, height: 1000)
    var model: BookPage
    var onChange: (BookPage) -> Void
    var onActivate: (() -> Void)?
    var tool: PaperTool = .text
    var fontName = "Baskerville"
    var fontSize: CGFloat = 30
    var ink = UIColor(hex: "#332A20")
    var selected: UUID?
    var backgroundImage: UIImage?
    private let backgroundView = UIImageView()
    private let drawingView = PKCanvasView()
    private let picker = PKToolPicker()
    private var textViews: [UUID: UITextView] = [:]
    private var pieces: [UUID: UIView] = [:]
    private var changing = false

    init(page: BookPage, background: UIImage? = nil, onChange: @escaping (BookPage) -> Void) {
        self.model = page
        self.onChange = onChange
        self.backgroundImage = background
        super.init(frame: CGRect(origin: .zero, size: Self.size))
        clipsToBounds = true
        backgroundView.frame = bounds
        backgroundView.contentMode = .scaleToFill
        addSubview(backgroundView)
        drawingView.frame = bounds
        drawingView.backgroundColor = .clear
        drawingView.isOpaque = false
        drawingView.isScrollEnabled = false
        drawingView.contentSize = Self.size
        drawingView.drawingPolicy = .anyInput
        drawingView.delegate = self
        picker.addObserver(drawingView)
        addSubview(drawingView)
        let tap = UITapGestureRecognizer(target: self, action: #selector(blankTap(_:)))
        tap.delegate = self
        addGestureRecognizer(tap)
        render(page)
    }
    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }

    private func prepared(_ page: BookPage) -> BookPage {
        var result = page
        if result.fragments == nil {
            result.fragments = []
            if !page.title.isEmpty {
                var title = TextFragment()
                title.text = page.title; title.y = 0.09; title.size = 40; title.color = page.ink
                result.fragments?.append(title)
            }
            if !page.text.isEmpty {
                var body = TextFragment()
                body.text = page.text; body.y = 0.23; body.size = 29; body.color = page.ink
                result.fragments?.append(body)
            }
        }
        return result
    }

    func render(_ page: BookPage) {
        changing = true
        defer { changing = false }
        model = prepared(page)
        let color: String
        switch page.paper {
        case "white": color = "#FAF9F2"
        case "blue": color = "#E4EBE9"
        case "rose": color = "#EEDFD9"
        default: color = "#F2E8D2"
        }
        backgroundView.image = backgroundImage ?? LibraryMaterials.texture("paper", color: color)
        let drawing = (page.drawing.flatMap { try? PKDrawing(data: $0) }) ?? PKDrawing()
        if drawingView.drawing.dataRepresentation() != drawing.dataRepresentation() { drawingView.drawing = drawing }
        let validTexts = Set((model.fragments ?? []).map(\.id))
        for id in Array(textViews.keys) where !validTexts.contains(id) { textViews.removeValue(forKey: id)?.removeFromSuperview() }
        for text in model.fragments ?? [] {
            let field: UITextView
            if let existing = textViews[text.id] { field = existing }
            else {
                field = UITextView()
                field.backgroundColor = .clear
                field.isScrollEnabled = false
                field.textContainerInset = .zero
                field.textContainer.lineFragmentPadding = 0
                field.delegate = self
                field.accessibilityIdentifier = text.id.uuidString
                textViews[text.id] = field
                addSubview(field)
                addGestures(to: field, twoFingerPan: true)
            }
            if !field.isFirstResponder { field.text = text.text }
            field.font = UIFont(name: text.font, size: text.size) ?? .systemFont(ofSize: text.size)
            field.textColor = UIColor(hex: text.color)
            layoutText(field, fragment: text)
        }
        let validPieces = Set(model.objects.map(\.id))
        for id in Array(pieces.keys) where !validPieces.contains(id) { pieces.removeValue(forKey: id)?.removeFromSuperview() }
        for object in model.objects {
            let piece: UIView
            if let existing = pieces[object.id] { piece = existing }
            else {
                if let data = object.image, let image = UIImage(data: data) {
                    let photo = UIImageView(image: image)
                    photo.contentMode = .scaleAspectFit
                    photo.backgroundColor = .white
                    piece = photo
                } else {
                    let label = UILabel()
                    label.text = object.symbol
                    label.textAlignment = .center
                    label.textColor = UIColor(hex: "#8A6143")
                    label.font = UIFont.systemFont(ofSize: 110)
                    piece = label
                }
                piece.accessibilityIdentifier = object.id.uuidString
                piece.isUserInteractionEnabled = true
                piece.layer.shadowColor = UIColor.black.cgColor
                piece.layer.shadowOpacity = 0.2
                piece.layer.shadowRadius = 4
                piece.layer.shadowOffset = CGSize(width: 2, height: 4)
                pieces[object.id] = piece
                addSubview(piece)
                addGestures(to: piece, twoFingerPan: false)
                let tap = UITapGestureRecognizer(target: self, action: #selector(selectPiece(_:)))
                piece.addGestureRecognizer(tap)
            }
            let width = Self.size.width * object.width
            let ratio = (piece as? UIImageView)?.image.map { $0.size.height / max(1, $0.size.width) } ?? 1
            piece.transform = .identity
            piece.bounds = CGRect(x: 0, y: 0, width: width, height: min(800, width * ratio))
            piece.center = CGPoint(x: Self.size.width * object.x, y: Self.size.height * object.y)
            piece.transform = CGAffineTransform(rotationAngle: object.rotation * .pi / 180)
        }
        bringSubviewToFront(drawingView)
        setTool(tool)
    }

    func setTool(_ next: PaperTool) {
        tool = next
        drawingView.isUserInteractionEnabled = next != .text
        if next == .text {
            sendSubviewToBack(drawingView)
            sendSubviewToBack(backgroundView)
            picker.setVisible(false, forFirstResponder: drawingView)
            if drawingView.isFirstResponder { drawingView.resignFirstResponder() }
        } else {
            endEditing(true)
            bringSubviewToFront(drawingView)
            drawingView.tool = next == .eraser ? PKEraserTool(.bitmap) : PKInkingTool(.pencil, color: ink, width: 4)
            drawingView.becomeFirstResponder()
            picker.setVisible(true, forFirstResponder: drawingView)
        }
    }
    func setFont(_ name: String, size: CGFloat, color: UIColor) {
        fontName = name; fontSize = size; ink = color
        guard let id = selected, let index = model.fragments?.firstIndex(where: { $0.id == id }) else { return }
        model.fragments?[index].font = name
        model.fragments?[index].size = Double(size)
        model.fragments?[index].color = color.hex
        if let field = textViews[id], let fragment = model.fragments?[index] {
            field.font = UIFont(name: name, size: size)
            field.textColor = color
            layoutText(field, fragment: fragment)
        }
        emit()
    }
    func addPhoto(_ data: Data) {
        var object = PageObject()
        object.image = data
        object.y = 0.5
        model.objects.append(object)
        selected = object.id
        emit(); render(model)
    }
    func addSymbol(_ symbol: String) {
        var object = PageObject()
        object.symbol = symbol; object.width = 0.2
        model.objects.append(object); selected = object.id
        emit(); render(model)
    }
    func removeSelected() {
        guard let id = selected else { return }
        model.objects.removeAll { $0.id == id }
        model.fragments?.removeAll { $0.id == id }
        selected = nil; emit(); render(model)
    }
    private func layoutText(_ field: UITextView, fragment: TextFragment) {
        field.transform = .identity
        let width = Self.size.width * fragment.width
        let height = max(50, field.sizeThatFits(CGSize(width: width, height: 10000)).height)
        field.bounds = CGRect(x: 0, y: 0, width: width, height: height)
        field.center = CGPoint(x: Self.size.width * fragment.x + width / 2,
                               y: Self.size.height * fragment.y + height / 2)
        field.transform = CGAffineTransform(rotationAngle: fragment.rotation * .pi / 180)
    }
    func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldReceive touch: UITouch) -> Bool {
        if gestureRecognizer.view !== self { return true }
        var node: UIView? = touch.view
        while let candidate = node, candidate !== self {
            if candidate is UITextView || pieces.values.contains(where: { $0 === candidate }) { return false }
            node = candidate.superview
        }
        return tool == .text
    }
    func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldRecognizeSimultaneouslyWith otherGestureRecognizer: UIGestureRecognizer) -> Bool {
        gestureRecognizer.view === otherGestureRecognizer.view
    }
    override func didMoveToWindow() {
        super.didMoveToWindow()
        for view in Array(pieces.values) + Array(textViews.values) {
            connectGestures(view)
        }
    }
    private func connectGestures(_ view: UIView) {
        var ancestor = superview
        while let node = ancestor {
            if let scroll = node as? UIScrollView {
                for gesture in view.gestureRecognizers ?? [] {
                    if gesture is UIPanGestureRecognizer { scroll.panGestureRecognizer.require(toFail: gesture) }
                    if gesture is UIPinchGestureRecognizer { scroll.pinchGestureRecognizer?.require(toFail: gesture) }
                }
                return
            }
            ancestor = node.superview
        }
    }
    private func addGestures(to view: UIView, twoFingerPan: Bool) {
        let pan = UIPanGestureRecognizer(target: self, action: #selector(movePiece(_:)))
        pan.minimumNumberOfTouches = twoFingerPan ? 2 : 1
        pan.delegate = self
        let pinch = UIPinchGestureRecognizer(target: self, action: #selector(scalePiece(_:)))
        pinch.delegate = self
        let rotate = UIRotationGestureRecognizer(target: self, action: #selector(rotatePiece(_:)))
        rotate.delegate = self
        view.addGestureRecognizer(pan); view.addGestureRecognizer(pinch); view.addGestureRecognizer(rotate)
        connectGestures(view)
    }
    @objc private func blankTap(_ gesture: UITapGestureRecognizer) {
        guard tool == .text else { return }
        onActivate?()
        let point = gesture.location(in: self)
        var fragment = TextFragment()
        fragment.x = min(0.85, max(0.02, point.x / Self.size.width))
        fragment.y = min(0.94, max(0.02, point.y / Self.size.height))
        fragment.width = min(0.75, 0.97 - fragment.x)
        fragment.font = fontName; fragment.size = fontSize; fragment.color = ink.hex
        model.fragments?.append(fragment)
        selected = fragment.id
        emit(); render(model)
        textViews[fragment.id]?.becomeFirstResponder()
    }
    @objc private func selectPiece(_ gesture: UITapGestureRecognizer) {
        onActivate?()
        endEditing(true)
        selected = gesture.view?.accessibilityIdentifier.flatMap(UUID.init(uuidString:))
        for (id, view) in pieces {
            view.layer.borderWidth = id == selected ? 1 : 0
            view.layer.borderColor = UIColor.systemBrown.withAlphaComponent(0.6).cgColor
        }
    }
    @objc private func movePiece(_ gesture: UIPanGestureRecognizer) {
        guard let view = gesture.view, let id = view.accessibilityIdentifier.flatMap(UUID.init(uuidString:)) else { return }
        selected = id
        let translation = gesture.translation(in: self)
        if let index = model.objects.firstIndex(where: { $0.id == id }) {
            model.objects[index].x = min(0.95, max(0.05, model.objects[index].x + translation.x / Self.size.width))
            model.objects[index].y = min(0.95, max(0.05, model.objects[index].y + translation.y / Self.size.height))
        } else if let index = model.fragments?.firstIndex(where: { $0.id == id }) {
            model.fragments?[index].x = min(0.9, max(0, (model.fragments?[index].x ?? 0) + translation.x / Self.size.width))
            model.fragments?[index].y = min(0.94, max(0, (model.fragments?[index].y ?? 0) + translation.y / Self.size.height))
        }
        gesture.setTranslation(.zero, in: self)
        render(model)
        if gesture.state == .ended || gesture.state == .cancelled { emit() }
    }
    @objc private func rotatePiece(_ gesture: UIRotationGestureRecognizer) {
        guard let id = gesture.view?.accessibilityIdentifier.flatMap(UUID.init(uuidString:)) else { return }
        selected = id
        let degrees = gesture.rotation * 180 / .pi
        if let index = model.objects.firstIndex(where: { $0.id == id }) {
            model.objects[index].rotation = (model.objects[index].rotation + degrees).truncatingRemainder(dividingBy: 360)
        } else if let index = model.fragments?.firstIndex(where: { $0.id == id }) {
            model.fragments?[index].rotation = ((model.fragments?[index].rotation ?? 0) + degrees).truncatingRemainder(dividingBy: 360)
        }
        gesture.rotation = 0
        render(model)
        if gesture.state == .ended || gesture.state == .cancelled { emit() }
    }
    @objc private func scalePiece(_ gesture: UIPinchGestureRecognizer) {
        guard let id = gesture.view?.accessibilityIdentifier.flatMap(UUID.init(uuidString:)) else { return }
        selected = id
        if let index = model.objects.firstIndex(where: { $0.id == id }) {
            model.objects[index].width = min(0.9, max(0.15, model.objects[index].width * gesture.scale))
        } else if let index = model.fragments?.firstIndex(where: { $0.id == id }) {
            model.fragments?[index].size = min(100, max(16, (model.fragments?[index].size ?? 30) * gesture.scale))
        }
        gesture.scale = 1
        render(model)
        if gesture.state == .ended || gesture.state == .cancelled { emit() }
    }
    func textViewDidBeginEditing(_ textView: UITextView) {
        onActivate?()
        selected = textView.accessibilityIdentifier.flatMap(UUID.init(uuidString:))
    }
    func textViewDidChange(_ textView: UITextView) {
        guard let id = textView.accessibilityIdentifier.flatMap(UUID.init(uuidString:)),
              let index = model.fragments?.firstIndex(where: { $0.id == id }) else { return }
        model.fragments?[index].text = textView.text
        if let fragment = model.fragments?[index] { layoutText(textView, fragment: fragment) }
        emit()
    }
    func canvasViewDrawingDidChange(_ canvasView: PKCanvasView) {
        guard !changing else { return }
        model.drawing = canvasView.drawing.dataRepresentation()
    }
    func canvasViewDidBeginUsingTool(_ canvasView: PKCanvasView) { onActivate?() }
    func canvasViewDidEndUsingTool(_ canvasView: PKCanvasView) { emit() }
    private func emit() { if !changing { onChange(model) } }
}

struct PaperCommands: Equatable {
    var tool = PaperTool.text
    var font = "Baskerville"
    var fontSize = 30.0
    var ink = "#332A20"
    var image: Data?
    var symbol: String?
    var actionID = UUID()
    var deleteID = UUID()
}

struct BookDesk: UIViewControllerRepresentable {
    var pages: [BookPage]
    var index: Int
    var commands: PaperCommands
    var cover: UIImage? = nil
    var onChange: (BookPage) -> Void
    var onIndex: (Int) -> Void

    func makeUIViewController(context: Context) -> BookDeskController {
        let controller = BookDeskController()
        controller.configure(self)
        return controller
    }
    func updateUIViewController(_ controller: BookDeskController, context: Context) { controller.configure(self) }
}

@MainActor
final class BookDeskController: UIViewController, UIScrollViewDelegate {
    private let scroll = UIScrollView()
    private let book = UIView()
    private var left: PaperSurface?
    private var right: PaperSurface?
    private var configuration: BookDesk?
    private var spread = -1
    private var currentIndex = 0
    private var lastWidth: CGFloat = 0
    private var lastAction: UUID?
    private var lastDelete: UUID?
    private var lastFont = ""
    private var lastTool: PaperTool?
    private var flipping = false

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(hex: "#302821")
        scroll.frame = view.bounds
        scroll.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        scroll.contentInsetAdjustmentBehavior = .never
        scroll.keyboardDismissMode = .interactive
        scroll.minimumZoomScale = 0.2; scroll.maximumZoomScale = 1.5
        scroll.delegate = self
        scroll.addSubview(book)
        view.addSubview(scroll)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboard(_:)),
                                                name: UIResponder.keyboardWillChangeFrameNotification, object: nil)
    }
    deinit { NotificationCenter.default.removeObserver(self) }
    func configure(_ next: BookDesk) {
        loadViewIfNeeded()
        let previousIndex = currentIndex
        if configuration == nil {
            lastAction = next.commands.actionID
            lastDelete = next.commands.deleteID
        }
        configuration = next
        currentIndex = min(max(0, next.index), max(0, next.pages.count - 1))
        let nextSpread = next.cover == nil ? currentIndex / 2 : 0
        if spread != nextSpread || (left == nil && right == nil) {
            view.endEditing(true)
            if spread >= 0 && next.cover == nil {
                turn(to: nextSpread, forward: currentIndex > previousIndex)
            } else { install(spread: nextSpread); centerPage(animated: false) }
        } else {
            for surface in [left, right].compactMap({ $0 }) {
                if let changed = next.pages.first(where: { $0.id == surface.model.id }),
                   changed != surface.model {
                    surface.backgroundImage = next.cover
                    surface.render(changed)
                }
            }
            if previousIndex != currentIndex { view.endEditing(true); centerPage(animated: true) }
        }
        if !flipping { applyCommands(next.commands, force: previousIndex != currentIndex) }
    }
    private var active: PaperSurface? { configuration?.cover != nil || currentIndex % 2 == 0 ? left : right }

    private func install(spread target: Int) {
        guard let configuration else { return }
        for child in book.subviews { child.removeFromSuperview() }
        left = nil; right = nil
        spread = target
        let indices = configuration.cover != nil ? [0] : [target * 2, target * 2 + 1]
        let width = PaperSurface.size.width
        book.bounds = CGRect(x: 0, y: 0, width: width * CGFloat(indices.count), height: PaperSurface.size.height)
        book.frame = book.bounds
        book.layer.shadowColor = UIColor.black.cgColor
        book.layer.shadowOpacity = 0.4
        book.layer.shadowRadius = 16
        book.layer.shadowOffset = CGSize(width: 0, height: 9)
        for (side, index) in indices.enumerated() {
            guard configuration.pages.indices.contains(index) else {
                let blank = UIView(frame: CGRect(x: width, y: 0, width: width, height: PaperSurface.size.height))
                blank.backgroundColor = UIColor(hex: "#E8DDC5")
                blank.tag = 990
                book.addSubview(blank)
                continue
            }
            let page = configuration.pages[index]
            let surface = PaperSurface(page: page, background: configuration.cover) { [weak self] changed in
                guard let callback = self?.configuration?.onChange else { return }
                DispatchQueue.main.async { callback(changed) }
            }
            surface.onActivate = { [weak self] in
                guard let self, self.currentIndex != index else { return }
                self.configuration?.onIndex(index)
            }
            surface.frame.origin.x = CGFloat(side) * width
            book.addSubview(surface)
            if side == 0 { left = surface } else { right = surface }
        }
        for view in book.subviews where view.tag == 991 { view.removeFromSuperview() }
        if configuration.cover == nil {
            let gutter = UIImageView(image: Self.gutter())
            gutter.frame = CGRect(x: width - 18, y: 0, width: 36, height: PaperSurface.size.height)
            gutter.isUserInteractionEnabled = false
            gutter.tag = 991
            book.addSubview(gutter)
        }
        scroll.contentSize = CGSize(width: book.bounds.width * scroll.zoomScale, height: book.bounds.height * scroll.zoomScale)
        applyCommands(configuration.commands, force: true)
    }
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        // Only viewport width changes alter the page zoom. Keyboard height never rescales paper.
        if abs(lastWidth - view.bounds.width) > 1 {
            lastWidth = view.bounds.width
            let fit = max(0.2, (view.bounds.width - 26) / PaperSurface.size.width)
            scroll.minimumZoomScale = fit * 0.7
            scroll.setZoomScale(fit, animated: false)
            scroll.contentSize = CGSize(width: book.bounds.width * fit, height: book.bounds.height * fit)
            centerPage(animated: false)
        }
    }
    private func centerPage(animated: Bool) {
        let side = configuration?.cover != nil ? 0 : currentIndex % 2
        let pageWidth = PaperSurface.size.width * scroll.zoomScale
        let target = CGFloat(side) * pageWidth - max(0, (scroll.bounds.width - pageWidth) / 2)
        scroll.setContentOffset(CGPoint(x: max(0, target), y: scroll.contentOffset.y), animated: animated)
    }
    private func turn(to target: Int, forward: Bool) {
        guard !flipping else { return }
        flipping = true
        // The turning sheet pivots about the binding. The following spread recenters on its first sheet.
        let snapshot = book.snapshotView(afterScreenUpdates: false)
        if let snapshot {
            snapshot.frame = scroll.convert(book.frame, to: view)
            view.addSubview(snapshot)
            var perspective = CATransform3DIdentity
            perspective.m34 = -1 / 1600
            snapshot.layer.transform = perspective
            UIView.animate(withDuration: 0.34, animations: {
                snapshot.layer.transform = CATransform3DRotate(perspective, forward ? -.pi / 2 : .pi / 2, 0, 1, 0)
                snapshot.alpha = 0.3
            }, completion: { [weak self] _ in
                guard let self else { return }
                self.install(spread: target)
                self.centerPage(animated: false)
                snapshot.removeFromSuperview()
                self.flipping = false
                let latest = self.configuration?.cover == nil ? self.currentIndex / 2 : 0
                if latest != self.spread { self.turn(to: latest, forward: latest > self.spread) }
            })
        } else {
            install(spread: target); centerPage(animated: false); flipping = false
        }
    }
    private func applyCommands(_ commands: PaperCommands, force: Bool = false) {
        let fontKey = commands.font + String(commands.fontSize) + commands.ink
        for surface in [left, right].compactMap({ $0 }) {
            surface.fontName = commands.font
            surface.fontSize = commands.fontSize
            surface.ink = UIColor(hex: commands.ink)
            if force || lastTool != commands.tool { surface.setTool(surface === active ? commands.tool : .text) }
        }
        if !force && lastFont != fontKey { active?.setFont(commands.font, size: commands.fontSize, color: UIColor(hex: commands.ink)) }
        lastFont = fontKey; lastTool = commands.tool
        if lastAction != commands.actionID {
            if let image = commands.image { active?.addPhoto(image) }
            if let symbol = commands.symbol { active?.addSymbol(symbol) }
            lastAction = commands.actionID
        }
        if lastDelete != commands.deleteID {
            if lastDelete != nil { active?.removeSelected() }
            lastDelete = commands.deleteID
        }
    }
    func viewForZooming(in scrollView: UIScrollView) -> UIView? { book }
    func scrollViewDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        if !decelerate { syncIndex() }
    }
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) { syncIndex() }
    private func syncIndex() {
        guard configuration?.cover == nil else { return }
        let width = PaperSurface.size.width * scroll.zoomScale
        let side = scroll.contentOffset.x + scroll.bounds.width / 2 > width ? 1 : 0
        let candidate = spread * 2 + side
        if configuration?.pages.indices.contains(candidate) == true && candidate != currentIndex { configuration?.onIndex(candidate) }
    }
    @objc private func keyboard(_ note: Notification) {
        guard let frame = note.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? CGRect else { return }
        let local = view.convert(frame, from: nil)
        let overlap = max(0, view.bounds.maxY - local.minY)
        scroll.contentInset.bottom = overlap
        scroll.verticalScrollIndicatorInsets.bottom = overlap
        // Expose the text being edited by scrolling the entire book, preserving all local coordinates.
        if overlap > 0, let field = view.firstResponderView {
            let rect = field.convert(field.bounds, to: scroll)
            scroll.scrollRectToVisible(rect.insetBy(dx: -20, dy: -25), animated: true)
        }
    }
    private static func gutter() -> UIImage {
        UIGraphicsImageRenderer(size: CGSize(width: 36, height: 32)).image { renderer in
            let colors = [UIColor.clear.cgColor, UIColor.black.withAlphaComponent(0.21).cgColor, UIColor.clear.cgColor] as CFArray
            if let gradient = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(), colors: colors, locations: [0, 0.5, 1]) {
                renderer.cgContext.drawLinearGradient(gradient, start: .zero, end: CGPoint(x: 36, y: 0), options: [])
            }
        }
    }
}

private extension UIView {
    var firstResponderView: UIView? {
        if isFirstResponder { return self }
        for view in subviews { if let found = view.firstResponderView { return found } }
        return nil
    }
}
