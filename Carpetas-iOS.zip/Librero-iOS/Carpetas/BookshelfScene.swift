import SwiftUI
import SceneKit
import UIKit

@MainActor
private final class ShelfViewport: SCNView {
    var resized: (() -> Void)?
    private var oldSize = CGSize.zero
    override func layoutSubviews() {
        super.layoutSubviews()
        if bounds.size != oldSize {
            oldSize = bounds.size
            resized?()
        }
    }
}

struct BookshelfScene: UIViewRepresentable {
    var state: LibraryState
    var revision: Int
    var onOpen: (UUID) -> Void
    var onMove: (UUID, Int, Double, Double, Double, Double) -> Void
    var onInspect: (UUID) -> Void

    func makeCoordinator() -> Coordinator { Coordinator(self) }
    func makeUIView(context: Context) -> SCNView {
        let view = ShelfViewport()
        view.backgroundColor = UIColor(hex: "#241D17")
        view.antialiasingMode = .multisampling4X
        view.preferredFramesPerSecond = 60
        view.isPlaying = true
        view.autoenablesDefaultLighting = false
        context.coordinator.view = view
        context.coordinator.build()
        let c = context.coordinator
        view.resized = { [weak c] in c?.cameraPosition() }
        let pan = UIPanGestureRecognizer(target: c, action: #selector(Coordinator.pan(_:)))
        pan.maximumNumberOfTouches = 1
        pan.delegate = c
        view.addGestureRecognizer(pan)
        let tap = UITapGestureRecognizer(target: c, action: #selector(Coordinator.tap(_:)))
        view.addGestureRecognizer(tap)
        let hold = UILongPressGestureRecognizer(target: c, action: #selector(Coordinator.hold(_:)))
        hold.minimumPressDuration = 0.35
        hold.delegate = c
        view.addGestureRecognizer(hold)
        tap.require(toFail: hold)
        let rotate = UIRotationGestureRecognizer(target: c, action: #selector(Coordinator.rotate(_:)))
        rotate.delegate = c
        view.addGestureRecognizer(rotate)
        let pinch = UIPinchGestureRecognizer(target: c, action: #selector(Coordinator.pinch(_:)))
        pinch.delegate = c
        view.addGestureRecognizer(pinch)
        return view
    }
    func updateUIView(_ view: SCNView, context: Context) {
        let c = context.coordinator
        let changed = c.parent.revision != revision
        c.parent = self
        if changed { c.synchronize() }

    }

    @MainActor
    final class Coordinator: NSObject, UIGestureRecognizerDelegate {
        var parent: BookshelfScene
        weak var view: SCNView?
        var scene = SCNScene()
        var camera = SCNNode()
        var active: SCNNode?
        var origin = SCNVector3Zero
        var grabOffset = SCNVector3Zero
        var fingerHeld = false
        var startCameraY: Float = 0.3
        var cameraY: Float = 0.3
        var rotationStart: Float = 0
        var scaleStart: Float = 1
        var animating = false
        var selectedShelf = 0
        var nodes: [UUID: SCNNode] = [:]
        var applied: LibraryState?
        let cabinet = SCNNode()
        var manipulationGestures: Set<ObjectIdentifier> = []
        var lastOpeningTransform = SCNMatrix4Identity

        init(_ parent: BookshelfScene) { self.parent = parent }
        func boardY(_ shelf: Int) -> Float { 2.8 - Float(shelf) * 2.4 }

        func box(_ width: CGFloat, _ height: CGFloat, _ depth: CGFloat, material: SCNMaterial,
                 position: SCNVector3, parent root: SCNNode, bevel: CGFloat = 0) -> SCNNode {
            let geometry = SCNBox(width: width, height: height, length: depth, chamferRadius: bevel)
            geometry.materials = [material]
            let node = SCNNode(geometry: geometry)
            node.position = position
            root.addChildNode(node)
            return node
        }
        func build() {
            guard let view, !animating else { return }
            scene = SCNScene()
            scene.physicsWorld.gravity = SCNVector3(0, -9.8, 0)
            scene.background.contents = UIColor(hex: "#31281F")
            scene.rootNode.addChildNode(cabinet)
            updateCabinet()
            for book in parent.state.books { addBook(book) }
            for object in parent.state.objects { addObject(object) }
            applied = parent.state
            camera = SCNNode()
            camera.camera = SCNCamera()
            camera.camera?.fieldOfView = 49
            camera.camera?.wantsHDR = false
            camera.camera?.exposureOffset = -0.1
            scene.rootNode.addChildNode(camera)
            let key = SCNNode()
            key.light = SCNLight()
            key.light?.type = .omni
            key.light?.intensity = 650
            key.light?.color = UIColor(red: 1, green: 0.88, blue: 0.72, alpha: 1)
            key.light?.castsShadow = true
            key.light?.shadowMode = .deferred
            key.light?.shadowRadius = 5
            key.position = SCNVector3(-2, 7, 6)
            scene.rootNode.addChildNode(key)
            let ambient = SCNNode()
            ambient.light = SCNLight()
            ambient.light?.type = .ambient
            ambient.light?.intensity = 260
            ambient.light?.color = UIColor(red: 0.85, green: 0.84, blue: 0.82, alpha: 1)
            scene.rootNode.addChildNode(ambient)
            view.scene = scene
            view.pointOfView = camera
            cameraPosition()
        }
        func updateCabinet() {
            cabinet.childNodes.forEach { $0.removeFromParentNode() }
            let color = parent.state.wood == "oak" ? "#8B6846" : parent.state.wood == "ebony" ? "#302A25" : "#60432F"
            let timber = LibraryMaterials.material("wood", color: color)
            let backing = LibraryMaterials.material("wood", color: parent.state.wood == "oak" ? "#4C3A2D" : "#30261F")
            let bottom = boardY(parent.state.shelves - 1) - 0.2
            let top = boardY(0) + 2.4
            let back = box(6.6, max(18, CGFloat(top - bottom + 3)), 0.1, material: backing,
                           position: SCNVector3(0, (top + bottom) / 2, -0.72), parent: cabinet)
            back.castsShadow = false
            for shelf in 0..<parent.state.shelves {
                _ = box(6.5, 0.18, 1.7, material: timber,
                        position: SCNVector3(0, boardY(shelf), 0), parent: cabinet, bevel: 0.018)
                let trim = LibraryMaterials.material("wood", color: color)
                _ = box(6.5, 0.085, 0.06, material: trim,
                        position: SCNVector3(0, boardY(shelf) - 0.035, 0.88), parent: cabinet, bevel: 0.008)
            }
        }

        // Keep the SCNScene, camera, lights and unrelated objects alive across edits.
        func synchronize() {
            guard !animating, active == nil else { return }
            let next = parent.state
            if applied?.wood != next.wood || applied?.shelves != next.shelves { updateCabinet() }
            let ids = Set(next.books.map(\.id) + next.objects.map(\.id))
            for id in Array(nodes.keys) where !ids.contains(id) {
                nodes.removeValue(forKey: id)?.removeFromParentNode()
            }
            for book in next.books {
                if let old = applied?.books.first(where: { $0.id == book.id }), let node = nodes[book.id] {
                    var appearance = old
                    appearance.x = book.x; appearance.shelf = book.shelf; appearance.elevation = book.elevation
                    appearance.tilt = book.tilt; appearance.horizontal = book.horizontal; appearance.pages = book.pages
                    if appearance == book { pose(book, node: node) }
                    else { node.removeFromParentNode(); addBook(book) }
                } else { addBook(book) }
            }
            for object in next.objects {
                if let old = applied?.objects.first(where: { $0.id == object.id }), let node = nodes[object.id],
                   old.kind == object.kind, old.color == object.color {
                    pose(object, node: node)
                } else {
                    nodes[object.id]?.removeFromParentNode()
                    addObject(object)
                }
            }
            applied = next
        }
        func bottomOffset(_ node: SCNNode) -> Float {
            let bounds = node.boundingBox
            let angle = node.eulerAngles.z
            let ys = [bounds.min.x, bounds.max.x].flatMap { x in
                [bounds.min.y, bounds.max.y].map { y in
                    (sin(angle) * x + cos(angle) * y) * node.scale.y
                }
            }
            return -(ys.min() ?? 0)
        }
        func pose(_ book: LibraryBook, node: SCNNode) {
            node.eulerAngles = SCNVector3(0, 0, book.horizontal ? .pi / 2 : Float(book.tilt * .pi / 180))
            node.position = SCNVector3(Float(book.x), boardY(book.shelf) + 0.1 + bottomOffset(node) + Float(book.elevation), 0.1)
        }
        func pose(_ object: ShelfObject, node: SCNNode) {
            node.eulerAngles = SCNVector3(0, 0, Float((object.rotation ?? 0) * .pi / 180))
            node.scale = SCNVector3(Float(object.scale), Float(object.scale), Float(object.scale))
            node.position = SCNVector3(Float(object.x), boardY(object.shelf) + 0.1 + bottomOffset(node) + Float(object.elevation ?? 0), 0.25)
        }

        func cameraPosition() {
            let aspect = max(0.4, Float((view?.bounds.width ?? 390) / max(view?.bounds.height ?? 844, 1)))
            camera.camera?.usesOrthographicProjection = true
            camera.camera?.orthographicScale = Double(3.12 / aspect)
            cameraY = min(4.0, max(boardY(parent.state.shelves - 1) + 1.1, cameraY))
            camera.position = SCNVector3(0, cameraY, 12)
            camera.eulerAngles = SCNVector3(-0.018, 0, 0)
        }

        func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldRecognizeSimultaneouslyWith otherGestureRecognizer: UIGestureRecognizer) -> Bool {
            !(gestureRecognizer is UITapGestureRecognizer || otherGestureRecognizer is UITapGestureRecognizer)
        }
        func gestureRecognizerShouldBegin(_ gestureRecognizer: UIGestureRecognizer) -> Bool {
            if gestureRecognizer is UIPanGestureRecognizer {
                return active != nil || hit(gestureRecognizer.location(in: view)) == nil
            }
            return !animating
        }

        func addBook(_ book: LibraryBook) {
            let root = SCNNode()
            root.name = book.id.uuidString
            let h = CGFloat(book.height), t = CGFloat(book.thickness), depth: CGFloat = 1.12
            let cover = LibraryMaterials.material(book.material, color: book.color)
            let paper = LibraryMaterials.material("paper", color: "#E9DFC6")
            _ = box(t - 0.045, h - 0.07, depth - 0.055, material: paper, position: .init(0, 0, 0), parent: root, bevel: 0.008)
            // The covers are separate pieces; the right board has a hinge at the spine.
            _ = box(0.025, h, depth, material: cover, position: .init(-Float(t / 2), 0, 0), parent: root, bevel: 0.009)
            let hinge = SCNNode()
            hinge.name = "hinge"
            hinge.position = SCNVector3(Float(t / 2), 0, Float(depth / 2))
            root.addChildNode(hinge)
            let coverNode = box(0.025, h, depth, material: cover, position: .init(0, 0, -Float(depth / 2)), parent: hinge, bevel: 0.009)
            let face = SCNPlane(width: depth, height: h)
            face.firstMaterial?.diffuse.contents = LibraryMaterials.cover(book, spine: false)
            face.firstMaterial?.lightingModel = .physicallyBased
            face.firstMaterial?.roughness.contents = 0.7
            let faceNode = SCNNode(geometry: face)
            faceNode.eulerAngles.y = .pi / 2
            faceNode.position.x = 0.014
            coverNode.addChildNode(faceNode)
            let spine = SCNPlane(width: t, height: h)
            spine.firstMaterial?.diffuse.contents = LibraryMaterials.cover(book, spine: true)
            spine.firstMaterial?.lightingModel = .physicallyBased
            spine.firstMaterial?.roughness.contents = 0.7
            let spineNode = SCNNode(geometry: spine)
            spineNode.position.z = Float(depth / 2) + 0.002
            root.addChildNode(spineNode)
            let angle = book.horizontal ? Double.pi / 2 : book.tilt * .pi / 180
            let height = Float(abs(cos(angle)) * Double(h) + abs(sin(angle)) * Double(t))
            root.position = SCNVector3(Float(book.x), boardY(book.shelf) + 0.07 + height / 2 + 0.025 + Float(book.elevation), 0.1)
            root.eulerAngles.z = book.horizontal ? .pi / 2 : Float(book.tilt * .pi / 180)
            let shape = SCNPhysicsShape(geometry: SCNBox(width: t + 0.03, height: h, length: depth, chamferRadius: 0), options: nil)
            let body = SCNPhysicsBody(type: .kinematic, shape: shape)
            body.mass = 0.7
            body.friction = 0.8
            body.restitution = 0.04
            body.damping = 0.85
            body.angularDamping = 0.9
            body.velocityFactor = SCNVector3(1, 1, 0)
            body.angularVelocityFactor = SCNVector3(0, 0, 1)
            root.physicsBody = body
            pose(book, node: root)
            nodes[book.id] = root
            scene.rootNode.addChildNode(root)
        }

        func addObject(_ object: ShelfObject) {
            let root = SCNNode()
            root.name = object.id.uuidString
            root.addChildNode(DecorFactory.make(object.kind, color: object.color))
            root.scale = SCNVector3(Float(object.scale), Float(object.scale), Float(object.scale))
            root.eulerAngles.z = Float((object.rotation ?? 0) * .pi / 180)
            root.position = SCNVector3(Float(object.x), boardY(object.shelf) + 0.075, 0.25)
            root.physicsBody = SCNPhysicsBody(type: .kinematic, shape: SCNPhysicsShape(node: root, options: nil))
            pose(object, node: root)
            nodes[object.id] = root
            scene.rootNode.addChildNode(root)
        }

        func hit(_ point: CGPoint) -> SCNNode? {
            guard let view else { return nil }
            for result in view.hitTest(point, options: nil) {
                var node: SCNNode? = result.node
                while let candidate = node {
                    if let name = candidate.name, UUID(uuidString: name) != nil { return candidate }
                    node = candidate.parent
                }
            }
            return nil
        }
        func begin(_ node: SCNNode) {
            guard active == nil else { return }
            active = node
            node.removeAllActions()
            origin = node.position
            node.position = origin
            node.physicsBody?.type = .kinematic
            rotationStart = node.eulerAngles.z
            scaleStart = node.scale.x
            UIImpactFeedbackGenerator(style: .soft).impactOccurred()
        }
        func moveHeld(_ point: CGPoint) {
            guard let active, let view else { return }
            let depth = view.projectPoint(active.position).z
            let world = view.unprojectPoint(SCNVector3(Float(point.x), Float(point.y), depth))
            active.position.x = min(2.65, max(-2.65, world.x + grabOffset.x))
            active.position.y = world.y + grabOffset.y
            let base = active.position.y - 0.6
            selectedShelf = (0..<parent.state.shelves).min { abs(boardY($0) - base) < abs(boardY($1) - base) } ?? 0
            if point.y < 100 { cameraY = min(4, cameraY + 0.035) }
            if point.y > view.bounds.height - 100 {
                cameraY = max(boardY(parent.state.shelves - 1) + 1.1, cameraY - 0.035)
            }
            camera.position.y = cameraY
        }
        func commit() {
            guard let node = active, let name = node.name, let id = UUID(uuidString: name) else { active = nil; return }
            active = nil
            let angle = Double(node.eulerAngles.z) * 180 / .pi
            let base = node.position.y - bottomOffset(node)
            let shelf = (0..<parent.state.shelves).min { abs(boardY($0) - base) < abs(boardY($1) - base) } ?? 0
            let elevation = min(1.8, max(0, Double(base - boardY(shelf) - 0.1)))
            // Settle this object only. Other books retain their exact transforms.
            node.position.y = boardY(shelf) + 0.1 + bottomOffset(node) + Float(elevation)
            parent.onMove(id, shelf, Double(node.position.x), elevation, angle, Double(node.scale.x))
        }
        func finishIfIdle() {
            DispatchQueue.main.async { [weak self] in
                guard let self, self.manipulationGestures.isEmpty else { return }
                self.commit()
            }
        }
        @objc func hold(_ gesture: UILongPressGestureRecognizer) {
            guard !animating else { return }
            switch gesture.state {
            case .began:
                if let node = hit(gesture.location(in: view)), let view {
                    begin(node)
                    let point = gesture.location(in: view)
                    let world = view.unprojectPoint(SCNVector3(Float(point.x), Float(point.y), view.projectPoint(node.position).z))
                    grabOffset = SCNVector3(node.position.x - world.x, node.position.y - world.y, 0)
                    fingerHeld = true
                    manipulationGestures.insert(ObjectIdentifier(gesture))
                }
            case .changed:
                if fingerHeld { moveHeld(gesture.location(in: view)) }
            case .ended, .cancelled:
                fingerHeld = false
                manipulationGestures.remove(ObjectIdentifier(gesture))
                finishIfIdle()
            default: break
            }
        }
        @objc func rotate(_ gesture: UIRotationGestureRecognizer) {
            if gesture.state == .began {
                if let node = hit(gesture.location(in: view)) { begin(node) }
                if active != nil { manipulationGestures.insert(ObjectIdentifier(gesture)) }
                rotationStart = active?.eulerAngles.z ?? 0
            }
            if gesture.state == .changed { active?.eulerAngles.z = rotationStart - Float(gesture.rotation) }
            if gesture.state == .ended || gesture.state == .cancelled {
                manipulationGestures.remove(ObjectIdentifier(gesture))
                finishIfIdle()
            }
        }
        @objc func pinch(_ gesture: UIPinchGestureRecognizer) {
            if gesture.state == .began {
                if let node = hit(gesture.location(in: view)),
                   let id = node.name.flatMap(UUID.init(uuidString:)),
                   parent.state.objects.contains(where: { $0.id == id }) {
                    begin(node)
                    scaleStart = node.scale.x
                    manipulationGestures.insert(ObjectIdentifier(gesture))
                }
            }
            if gesture.state == .changed, let node = active,
               let id = node.name.flatMap(UUID.init(uuidString:)), parent.state.objects.contains(where: { $0.id == id }) {
                let scale = min(2, max(0.2, scaleStart * Float(gesture.scale)))
                node.scale = SCNVector3(scale, scale, scale)
            }
            if gesture.state == .ended || gesture.state == .cancelled {
                manipulationGestures.remove(ObjectIdentifier(gesture))
                finishIfIdle()
            }
        }
        @objc func tap(_ gesture: UITapGestureRecognizer) {
            guard !animating, let node = hit(gesture.location(in: view)),
                  let name = node.name, let id = UUID(uuidString: name) else { return }
            if parent.state.books.contains(where: { $0.id == id }) { extract(node, id: id) }
            else { parent.onInspect(id) }
        }
        @objc func pan(_ gesture: UIPanGestureRecognizer) {
            guard let view, !animating else { return }
            if active != nil { return }
            if gesture.state == .began { startCameraY = cameraY }
            if gesture.state == .changed {
                let units = Float(2 * (camera.camera?.orthographicScale ?? 6)) / Float(max(1, view.bounds.height))
                cameraY = min(4, max(boardY(parent.state.shelves - 1) + 1.1,
                                    startCameraY + Float(gesture.translation(in: view).y) * units))
                camera.position.y = cameraY
            }
        }
        func extract(_ node: SCNNode, id: UUID) {
            guard !animating else { return }
            animating = true
            lastOpeningTransform = node.transform
            UIImpactFeedbackGenerator(style: .soft).impactOccurred()
            let target = SCNVector3(0, camera.position.y, camera.position.z - 3.3)
            let move = SCNAction.move(to: target, duration: 0.45)
            let scale = SCNAction.scale(to: 2.1, duration: 0.45)
            move.timingMode = .easeInEaseOut
            let rotate = SCNAction.rotateTo(x: 0, y: -.pi / 2, z: 0, duration: 0.45)
            node.runAction(.sequence([.group([move, rotate, scale]), .wait(duration: 0.12)])) { [weak self, weak node] in
                DispatchQueue.main.async {
                    guard let self, let node else { return }
                    node.childNode(withName: "hinge", recursively: false)?.runAction(.rotateBy(x: 0, y: -2.6, z: 0, duration: 0.4))
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.42) {
                        self.parent.onOpen(id)
                        node.transform = self.lastOpeningTransform
                        node.childNode(withName: "hinge", recursively: false)?.eulerAngles.y = 0
                        self.animating = false
                        self.synchronize()
                    }
                }
            }
        }
    }
}
