import SwiftUI
import PhotosUI
import UniformTypeIdentifiers

@main
struct CarpetasApp: App {
    @StateObject private var store = LibraryStore()
    var body: some Scene {
        WindowGroup {
            LibraryView()
                .environmentObject(store)
                .preferredColorScheme(.light)
        }
    }
}

private struct Selection: Identifiable { let id: UUID }

struct LibraryView: View {
    @EnvironmentObject private var store: LibraryStore
    @State private var arranging = false
    @State private var shelf = 0
    @State private var reading: Selection?
    @State private var editing: Selection?
    @State private var decoration: Selection?
    @State private var importing = false
    @State private var pendingImport: Data?
    @State private var confirmImport = false
    @State private var exporting = false
    @State private var backup = BackupDocument(data: Data())
    @State private var showHelp = false

    var body: some View {
        ZStack {
            BookshelfScene(state: store.state, arranging: arranging, focusShelf: shelf, revision: store.revision,
                           onOpen: { reading = Selection(id: $0) },
                           onMove: { store.place(id: $0, shelf: $1, x: $2, elevation: $3) },
                           onInspect: inspect)
                .ignoresSafeArea()
            VStack {
                HStack(alignment: .top) {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("Carpetas").font(.system(size: 32, weight: .regular, design: .serif))
                        Text(arranging ? "Coloca tus libros y adornos" : "Tu biblioteca personal")
                            .font(.caption).foregroundStyle(.white.opacity(0.75))
                    }
                    Spacer()
                    Menu {
                        Button("Nuevo libro", systemImage: "book.closed") {
                            editing = Selection(id: store.addBook())
                        }
                        Button("Añadir adorno", systemImage: "leaf") {
                            decoration = Selection(id: store.addObject())
                        }
                        Button(arranging ? "Terminar de colocar" : "Organizar estantes", systemImage: "hand.draw") { arranging.toggle() }
                        Menu("Madera") {
                            Button("Nogal") { store.state.wood = "walnut"; store.save() }
                            Button("Roble") { store.state.wood = "oak"; store.save() }
                            Button("Ébano") { store.state.wood = "ebony"; store.save() }
                        }
                        if store.state.shelves < 8 {
                            Button("Añadir estante", systemImage: "plus") { store.state.shelves += 1; store.save() }
                        }
                        Divider()
                        Button("Importar respaldo", systemImage: "square.and.arrow.down") { importing = true }
                        Button("Exportar biblioteca", systemImage: "square.and.arrow.up") {
                            do { backup = BackupDocument(data: try store.export()); exporting = true }
                            catch { store.error = error.localizedDescription }
                        }
                        Button("Cómo usar", systemImage: "hand.point.up.left") { showHelp = true }
                    } label: {
                        Image(systemName: "ellipsis").font(.title3).frame(width: 44, height: 44)
                            .background(.ultraThinMaterial, in: Circle())
                    }
                    .accessibilityLabel("Opciones de la biblioteca")
                }
                .foregroundStyle(.white).padding(22)
                Spacer()
                if store.state.books.isEmpty {
                    VStack(spacing: 14) {
                        Text("El primer libro de tu biblioteca")
                            .font(.system(size: 24, design: .serif))
                        Text("Crea un libro o importa el respaldo de Carpetas.")
                            .font(.subheadline).multilineTextAlignment(.center)
                        Button("Crear libro") { editing = Selection(id: store.addBook()) }
                            .buttonStyle(.borderedProminent).tint(Color(red: 0.39, green: 0.28, blue: 0.19))
                    }
                    .padding(24).background(.regularMaterial, in: RoundedRectangle(cornerRadius: 20))
                    .padding(26)
                    Spacer()
                }
                HStack(spacing: 18) {
                    Button { shelf = max(0, shelf - 1) } label: { Image(systemName: "chevron.up") }
                        .disabled(shelf == 0)
                    Text("Estante \(shelf + 1) / \(store.state.shelves)")
                        .font(.system(.subheadline, design: .serif))
                    Button { shelf = min(store.state.shelves - 1, shelf + 1) } label: { Image(systemName: "chevron.down") }
                        .disabled(shelf == store.state.shelves - 1)
                    Divider().frame(height: 20)
                    Button { arranging.toggle() } label: {
                        Image(systemName: arranging ? "checkmark" : "hand.draw")
                    }
                    .accessibilityLabel(arranging ? "Terminar de organizar" : "Organizar")
                }
                .padding(.horizontal, 20).padding(.vertical, 14)
                .background(.regularMaterial, in: Capsule()).padding(.bottom, 20)
            }
        }
        .sheet(item: $editing) { selection in BookCustomizer(bookID: selection.id).environmentObject(store) }
        .sheet(item: $decoration) { selection in ObjectCustomizer(objectID: selection.id).environmentObject(store) }
        .fullScreenCover(item: $reading) { selection in BookReader(bookID: selection.id).environmentObject(store) }
        .fileImporter(isPresented: $importing, allowedContentTypes: [.json]) { result in
            do {
                let url = try result.get()
                let granted = url.startAccessingSecurityScopedResource()
                defer { if granted { url.stopAccessingSecurityScopedResource() } }
                pendingImport = try Data(contentsOf: url)
                confirmImport = true
            } catch { store.error = "No se pudo leer el respaldo. \(error.localizedDescription)" }
        }
        .confirmationDialog("¿Restaurar este respaldo?", isPresented: $confirmImport, titleVisibility: .visible) {
            Button("Restaurar biblioteca", role: .destructive) {
                guard let data = pendingImport else { return }
                do { try store.restore(data); shelf = 0 }
                catch { store.error = "El respaldo no tiene un formato válido de Carpetas." }
                pendingImport = nil
            }
            Button("Cancelar", role: .cancel) { pendingImport = nil }
        } message: { Text("Se sustituirá la biblioteca actual. Los respaldos de Android convierten carpetas en libros y archivos en páginas.") }
        .fileExporter(isPresented: $exporting, document: backup, contentType: .json, defaultFilename: "Carpetas-Biblioteca") { result in
            if case .failure(let error) = result { store.error = error.localizedDescription }
        }
        .alert("Biblioteca", isPresented: Binding(get: { store.error != nil }, set: { if !$0 { store.error = nil } })) {
            Button("Aceptar") { store.error = nil }
        } message: { Text(store.error ?? "") }
        .alert("Tu biblioteca", isPresented: $showHelp) {
            Button("Entendido", role: .cancel) {}
        } message: {
            Text("Desliza un libro hacia arriba, hacia ti, para sacarlo y abrirlo. También puedes tocarlo. Mantén pulsado para personalizar. Activa la mano para arrastrar libros y adornos entre los estantes visibles. Dentro del libro, escribe, añade páginas y arrastra las fotos y decoraciones.")
        }
    }

    private func inspect(_ id: UUID) {
        if store.book(id) != nil { editing = Selection(id: id) }
        else { decoration = Selection(id: id) }
    }
}

struct BookCustomizer: View {
    let bookID: UUID
    @EnvironmentObject private var store: LibraryStore
    @Environment(\.dismiss) private var dismiss
    @State private var draft = LibraryBook()
    @State private var coverItem: PhotosPickerItem?
    @State private var spineItem: PhotosPickerItem?
    @State private var confirmDelete = false
    @State private var photoError: String?
    @State private var loading = false

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    HStack {
                        Spacer()
                        Image(uiImage: LibraryMaterials.cover(draft, spine: false))
                            .resizable().scaledToFit().frame(height: 210)
                            .clipShape(RoundedRectangle(cornerRadius: 3))
                            .shadow(color: .black.opacity(0.3), radius: 8, x: 4, y: 7)
                        Image(uiImage: LibraryMaterials.cover(draft, spine: true))
                            .resizable().frame(width: 40, height: 210)
                        Spacer()
                    }.padding(.vertical, 10).listRowBackground(Color.clear)
                }
                Section("Cubierta y lomo") {
                    TextField("Título", text: $draft.title)
                    TextField("Texto del lomo (vacío usa el título)", text: $draft.spine)
                    TextField("Autor o inscripción", text: $draft.author)
                    ColorPicker("Encuadernación", selection: colorBinding(\.color), supportsOpacity: false)
                    ColorPicker("Letras y grabado", selection: colorBinding(\.lettering), supportsOpacity: false)
                    Picker("Material", selection: $draft.material) {
                        Text("Cuero").tag("leather"); Text("Lino").tag("linen"); Text("Papel").tag("paper")
                    }
                    Picker("Grabado", selection: $draft.ornament) {
                        Text("Marco doble").tag("frame"); Text("Estrella").tag("star"); Text("Liso").tag("plain")
                    }
                    PhotosPicker("Imagen de portada", selection: $coverItem, matching: .images)
                    PhotosPicker("Imagen del lomo", selection: $spineItem, matching: .images)
                    if draft.coverPhoto != nil { Button("Quitar imagen de portada") { draft.coverPhoto = nil } }
                    if draft.spinePhoto != nil { Button("Quitar imagen del lomo") { draft.spinePhoto = nil } }
                }
                Section("En el librero") {
                    Picker("Estante", selection: $draft.shelf) {
                        ForEach(0..<store.state.shelves, id: \.self) { Text("Estante \($0 + 1)").tag($0) }
                    }
                    LabeledContent("Posición") { Slider(value: $draft.x, in: -2.5...2.5) }
                    LabeledContent("Altura") { Slider(value: $draft.height, in: 1.0...2.1) }
                    LabeledContent("Grosor") { Slider(value: $draft.thickness, in: 0.22...0.7) }
                    LabeledContent("Inclinación") { Slider(value: $draft.tilt, in: -18...18) }
                    Toggle("Acostado", isOn: $draft.horizontal)
                    LabeledContent("Altura en la pila") { Slider(value: $draft.elevation, in: 0...1.8) }
                }
                Section { Button("Eliminar libro", role: .destructive) { confirmDelete = true } }
            }
            .navigationTitle("Encuadernación").navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancelar") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Guardar") { store.update(draft); dismiss() }.disabled(loading || draft.title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                }
            }
            .onAppear { if let book = store.book(bookID) { draft = book } }
            .onChange(of: coverItem) { _, item in load(item, spine: false) }
            .onChange(of: spineItem) { _, item in load(item, spine: true) }
            .confirmationDialog("¿Eliminar este libro y todas sus páginas?", isPresented: $confirmDelete, titleVisibility: .visible) {
                Button("Eliminar libro", role: .destructive) { store.removeBook(bookID); dismiss() }
            }
            .alert("Imagen", isPresented: Binding(get: { photoError != nil }, set: { if !$0 { photoError = nil } })) {
                Button("Aceptar", role: .cancel) {}
            } message: { Text(photoError ?? "") }
        }
    }
    private func colorBinding(_ key: WritableKeyPath<LibraryBook, String>) -> Binding<Color> {
        Binding(get: { Color(uiColor: UIColor(hex: draft[keyPath: key])) },
                set: { draft[keyPath: key] = UIColor($0).hex })
    }
    private func load(_ item: PhotosPickerItem?, spine: Bool) {
        guard let item else { return }
        loading = true
        Task { @MainActor in
            defer { loading = false }
            do {
                guard let data = try await item.loadTransferable(type: Data.self) else { throw CocoaError(.fileReadUnknown) }
                let photo = try LibraryStore.photo(data)
                if spine { draft.spinePhoto = photo } else { draft.coverPhoto = photo }
            } catch { photoError = "No se pudo cargar la foto." }
        }
    }
}

struct ObjectCustomizer: View {
    let objectID: UUID
    @EnvironmentObject private var store: LibraryStore
    @Environment(\.dismiss) private var dismiss
    @State private var draft = ShelfObject()
    var body: some View {
        NavigationStack {
            Form {
                Picker("Adorno", selection: $draft.kind) {
                    Text("Jarrón cerámico").tag("vase")
                    Text("Planta").tag("plant")
                    Text("Marco").tag("frame")
                    Text("Esfera").tag("sphere")
                }
                ColorPicker("Color", selection: Binding(get: { Color(uiColor: UIColor(hex: draft.color)) },
                                                       set: { draft.color = UIColor($0).hex }), supportsOpacity: false)
                Picker("Estante", selection: $draft.shelf) {
                    ForEach(0..<store.state.shelves, id: \.self) { Text("Estante \($0 + 1)").tag($0) }
                }
                LabeledContent("Posición") { Slider(value: $draft.x, in: -2.5...2.5) }
                LabeledContent("Tamaño") { Slider(value: $draft.scale, in: 0.4...1.3) }
                Button("Quitar adorno", role: .destructive) {
                    store.state.objects.removeAll { $0.id == objectID }; store.save(); dismiss()
                }
            }
            .navigationTitle("Adorno").navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancelar") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Guardar") {
                        if let index = store.state.objects.firstIndex(where: { $0.id == objectID }) {
                            store.state.objects[index] = draft; store.save()
                        }
                        dismiss()
                    }
                }
            }
            .onAppear { if let object = store.state.objects.first(where: { $0.id == objectID }) { draft = object } }
        }
    }
}
