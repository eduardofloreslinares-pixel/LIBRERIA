import Foundation
import SwiftUI
import UIKit
import UniformTypeIdentifiers

struct PageObject: Codable, Identifiable, Equatable {
    var id = UUID()
    var image: Data? = nil
    var symbol = "✦"
    var x = 0.5
    var y = 0.6
    var width = 0.45
    var rotation = -4.0
}

struct BookPage: Codable, Identifiable, Equatable {
    var id = UUID()
    var title = ""
    var text = ""
    var date = Date()
    var paper = "cream"
    var ink = "#332A20"
    var objects: [PageObject] = []
}

struct LibraryBook: Codable, Identifiable, Equatable {
    var id = UUID()
    var title = "Sin título"
    var spine = ""
    var author = ""
    var color = "#64372E"
    var lettering = "#D7B77B"
    var material = "leather"
    var ornament = "frame"
    var coverPhoto: Data? = nil
    var spinePhoto: Data? = nil
    var shelf = 0
    var x = -2.0
    var height = 1.65
    var thickness = 0.36
    var tilt = 0.0
    var horizontal = false
    var elevation = 0.0
    var pages: [BookPage] = [BookPage()]
}

struct ShelfObject: Codable, Identifiable, Equatable {
    var id = UUID()
    var kind = "vase"
    var color = "#48655A"
    var shelf = 0
    var x = 1.8
    var scale = 0.8
}

struct LibraryState: Codable, Equatable {
    var version = 1
    var books: [LibraryBook] = []
    var objects: [ShelfObject] = []
    var shelves = 4
    var wood = "walnut"
}

struct BackupDocument: FileDocument {
    static var readableContentTypes: [UTType] { [.json] }
    var data: Data
    init(data: Data) { self.data = data }
    init(configuration: ReadConfiguration) throws {
        guard let data = configuration.file.regularFileContents else { throw CocoaError(.fileReadCorruptFile) }
        self.data = data
    }
    func fileWrapper(configuration: WriteConfiguration) throws -> FileWrapper {
        FileWrapper(regularFileWithContents: data)
    }
}

extension UIColor {
    convenience init(hex: String) {
        let value = UInt32(hex.trimmingCharacters(in: CharacterSet.alphanumerics.inverted), radix: 16) ?? 0x64372E
        self.init(red: CGFloat((value >> 16) & 255) / 255,
                  green: CGFloat((value >> 8) & 255) / 255,
                  blue: CGFloat(value & 255) / 255, alpha: 1)
    }
    var hex: String {
        var r: CGFloat = 0, g: CGFloat = 0, b: CGFloat = 0, a: CGFloat = 0
        getRed(&r, green: &g, blue: &b, alpha: &a)
        return String(format: "#%02X%02X%02X", Int(r * 255), Int(g * 255), Int(b * 255))
    }
}

@MainActor
final class LibraryStore: ObservableObject {
    @Published var state = LibraryState()
    @Published var error: String? = nil
    @Published var revision = 0
    private var writable = true
    private let url: URL

    init() {
        url = URL.documentsDirectory.appending(path: "biblioteca.json")
        if FileManager.default.fileExists(atPath: url.path) {
            do { state = try Self.decode(Data(contentsOf: url)) }
            catch {
                writable = false
                self.error = "No se pudo abrir la biblioteca guardada. Puedes restaurar un respaldo desde el menú."
            }
        }
    }

    func save(sceneChange: Bool = true) {
        guard writable else { error = "Restaura un respaldo para recuperar la biblioteca antes de guardar."; return }
        do {
            let data = try JSONEncoder().encode(state)
            try data.write(to: url, options: [.atomic])
            if sceneChange { revision += 1 }
        } catch { self.error = "No se pudieron guardar los cambios. \(error.localizedDescription)" }
    }

    func book(_ id: UUID) -> LibraryBook? { state.books.first { $0.id == id } }
    func update(_ book: LibraryBook) {
        guard let index = state.books.firstIndex(where: { $0.id == book.id }) else { return }
        state.books[index] = book
        save()
    }
    func updatePage(bookID: UUID, page: BookPage) {
        guard let b = state.books.firstIndex(where: { $0.id == bookID }),
              let p = state.books[b].pages.firstIndex(where: { $0.id == page.id }) else { return }
        state.books[b].pages[p] = page
        save(sceneChange: false)
    }
    func addBook() -> UUID {
        var book = LibraryBook()
        book.shelf = min(state.shelves - 1, state.books.count / 9)
        book.x = -2.35 + Double(state.books.filter { $0.shelf == book.shelf }.count % 9) * 0.52
        state.books.append(book)
        save()
        return book.id
    }
    func removeBook(_ id: UUID) {
        state.books.removeAll { $0.id == id }
        save()
    }
    func place(id: UUID, shelf: Int, x: Double, elevation: Double) {
        if let index = state.books.firstIndex(where: { $0.id == id }) {
            state.books[index].shelf = shelf
            state.books[index].x = x
            state.books[index].elevation = elevation
        } else if let index = state.objects.firstIndex(where: { $0.id == id }) {
            state.objects[index].shelf = shelf
            state.objects[index].x = x
        }
        save()
    }
    func addObject() -> UUID {
        let object = ShelfObject()
        state.objects.append(object)
        save()
        return object.id
    }

    func restore(_ data: Data) throws {
        let next = try Self.decode(data)
        state = next
        writable = true
        save()
    }
    func export() throws -> Data { try JSONEncoder().encode(state) }

    private static func decode(_ data: Data) throws -> LibraryState {
        if let library = try? JSONDecoder().decode(LibraryState.self, from: data) {
            guard library.version == 1, (1...8).contains(library.shelves),
                  Set(library.books.map(\.id)).count == library.books.count,
                  Set(library.objects.map(\.id)).count == library.objects.count else { throw CocoaError(.fileReadCorruptFile) }
            for book in library.books {
                guard (0..<library.shelves).contains(book.shelf), book.x.isFinite, abs(book.x) <= 2.8,
                      (1.0...2.1).contains(book.height), (0.22...0.7).contains(book.thickness),
                      book.elevation.isFinite, (0...1.8).contains(book.elevation),
                      book.tilt.isFinite, abs(book.tilt) <= 18,
                      !book.pages.isEmpty, Set(book.pages.map(\.id)).count == book.pages.count else { throw CocoaError(.fileReadCorruptFile) }
                for page in book.pages {
                    guard page.objects.allSatisfy({
                        $0.x.isFinite && $0.y.isFinite && (0...1).contains($0.x) &&
                        (0...1).contains($0.y) && (0.15...0.9).contains($0.width) &&
                        $0.rotation.isFinite && abs($0.rotation) <= 180
                    }) else { throw CocoaError(.fileReadCorruptFile) }
                }
            }
            guard library.objects.allSatisfy({
                (0..<library.shelves).contains($0.shelf) && $0.x.isFinite && abs($0.x) <= 2.8 &&
                (0.4...1.3).contains($0.scale)
            }) else { throw CocoaError(.fileReadCorruptFile) }
            return library
        }
        // Android backups map folders to books and each record to one page.
        let legacy = try JSONDecoder().decode(LegacyArchive.self, from: data)
        guard [1, 2].contains(legacy.version) else { throw CocoaError(.fileReadCorruptFile) }
        var result = LibraryState()
        result.shelves = min(8, max(4, (legacy.folders.count + 8) / 9))
        let dateFormatter = DateFormatter()
        dateFormatter.locale = Locale(identifier: "en_US_POSIX")
        dateFormatter.dateFormat = "yyyy-MM-dd"
        let colors = ["#64372E", "#304C43", "#23374F", "#705439", "#46384B"]
        for (index, folder) in legacy.folders.enumerated() {
            var book = LibraryBook()
            book.title = folder.name
            book.color = colors[index % colors.count]
            book.shelf = min(result.shelves - 1, index / 9)
            book.x = -2.3 + Double(index % 9) * 0.52
            book.pages = legacy.entries.filter { $0.folder == folder.id }.map { entry in
                var page = BookPage()
                page.title = entry.title
                page.text = entry.body
                page.date = dateFormatter.date(from: entry.date) ?? Date()
                page.objects = (entry.images ?? []).enumerated().compactMap { index, photo in
                    guard let encoded = photo.src.split(separator: ",").last,
                          let data = Data(base64Encoded: String(encoded)), UIImage(data: data) != nil else { return nil }
                    var object = PageObject()
                    object.image = data
                    object.x = index % 2 == 0 ? 0.3 : 0.7
                    object.y = min(0.85, 0.5 + Double(index / 2) * 0.15)
                    return object
                }
                return page
            }
            if book.pages.isEmpty { book.pages = [BookPage()] }
            result.books.append(book)
        }
        return result
    }

    static func photo(_ data: Data) throws -> Data {
        guard let image = UIImage(data: data) else { throw CocoaError(.fileReadCorruptFile) }
        let ratio = min(1, 1800 / max(image.size.width, image.size.height))
        let size = CGSize(width: image.size.width * ratio, height: image.size.height * ratio)
        let compressed = UIGraphicsImageRenderer(size: size).image { _ in image.draw(in: CGRect(origin: .zero, size: size)) }
        guard let jpeg = compressed.jpegData(compressionQuality: 0.85) else { throw CocoaError(.fileReadCorruptFile) }
        return jpeg
    }
}

private struct LegacyArchive: Decodable {
    var version: Int
    var folders: [LegacyFolder]
    var entries: [LegacyEntry]
}
private struct LegacyFolder: Decodable { var id: String; var name: String }
private struct LegacyPhoto: Decodable { var src: String }
private struct LegacyEntry: Decodable {
    var folder: String
    var title: String
    var body: String
    var date: String
    var images: [LegacyPhoto]?
}
