import SwiftUI
import SceneKit
import UIKit

struct BookshelfScene: UIViewRepresentable {
    var state: LibraryState
    var arranging: Bool
    var focusShelf: Int
    var revision: Int
    var onOpen: (UUID) -> Void
    var onMove: (UUID, Int, Double, Double) -> Void
    var onInspect: (UUID) -> Void

    func makeCoordinator() -> Coordinator { Coordinator(self) }
    func makeUIView(context: Context) -> SCNView {
        let view = SCNView()
        view.backgroundColor = UIColor(hex: "#241D17")
        view.antialiasingMode = .multisampling4X
        view.preferredFramesPerSecond = 60
        view.isPlaying = true
        view.autoenablesDefaultLighting = false
        context.coordinator.view = view
        context.coordinator.build()
        view.addGestureRecognizer(UIPanGestureRecognizer(target: context.coordinator, action: #selector(Coordinator.pan(_:))))
        view.addGestureRecognizer(UITapGestureRecognizer(target: context.coordinator, action: #selector(Coordinator.tap(_:))))
        let hold = UILongPressGestureRecognizer(target: context.coordinator, action: #selector(Coordinator.hold(_:)))
        view.addGestureRecognizer(hold)
        return view
    }
    func updateUIView(_ view: SCNView, context: Context) {
        let c = context.coordinator
        let changed = c.parent.revision != revision
        let focusChanged = c.parent.focusShelf != focusShelf
        c.parent = self
        if changed { c.build() }
        else if focusChanged { c.cameraPosition() }
    }

    @MainActor
    final class Coordinator: NSObject {
        var parent: BookshelfScene
        weak var view: SCNView?
        var scene = SCNScene()
        var camera = SCNNode()
        var active: SCNNode?
        var origin = SCNVector3Zero
        var pulling = false
        var animating = false
        var selectedShelf = 0

        init(_ parent: BookshelfScene) { self.parent = parent }
        func boardY(_ shelf: Int) -> Float { 2.8 - Float(shelf) * 2.4 }

        func box(_ width: CGFloat, _ height: CGFloat, _ depth: CGFloat, material: SCNMaterial,
                 position: SCNVector3, parent root: SCNNode, bevel: CGFloat = 0) -> SCNNode {
            let geometry = SCNBox(width: width, height: height, length: depth, chamferRadius: bevel)
            geometry.materials = [material]
            let node = SCNNode(geometry: geometry)
            node.position = position
            root.addChildNode(node)
            return node
        }
        func build() {
            guard let view, !animating else { return }
            scene = SCNScene()
            scene.physicsWorld.gravity = SCNVector3(0, -9.8, 0)
            scene.background.contents = UIColor(hex: "#31281F")
            let wood = parent.state.wood == "oak" ? "#9A7144" : parent.state.wood == "ebony" ? "#302A25" : "#63432C"
            let timber = LibraryMaterials.material("wood", color: wood)
            let back = box(6.4, CGFloat(parent.state.shelves) * 2.4 + 0.3, 0.12, material: timber,
                           position: SCNVector3(0, 3.0 - Float(parent.state.shelves - 1) * 1.2, -0.65), parent: scene.rootNode)
            back.castsShadow = false
            for shelf in 0..<parent.state.shelves {
                let board = box(6.4, 0.14, 1.65, material: timber,
                                position: SCNVector3(0, boardY(shelf), 0), parent: scene.rootNode, bevel: 0.025)
                board.physicsBody = SCNPhysicsBody(type: .static, shape: nil)
            }
            for x: Float in [-3.15, 3.15] {
                let wall = box(0.18, CGFloat(parent.state.shelves) * 2.4 + 0.3, 1.65, material: timber,
                               position: SCNVector3(x, 3.0 - Float(parent.state.shelves - 1) * 1.2, 0), parent: scene.rootNode)
                wall.physicsBody = SCNPhysicsBody(type: .static, shape: nil)
            }
            for book in parent.state.books { addBook(book) }
            for object in parent.state.objects { addObject(object) }
            camera = SCNNode()
            camera.camera = SCNCamera()
            camera.camera?.fieldOfView = 49
            camera.camera?.wantsHDR = true
            camera.camera?.exposureOffset = -0.1
            scene.rootNode.addChildNode(camera)
            let key = SCNNode()
            key.light = SCNLight()
            key.light?.type = .omni
            key.light?.intensity = 1050
            key.light?.color = UIColor(red: 1, green: 0.88, blue: 0.72, alpha: 1)
            key.light?.castsShadow = true
            key.light?.shadowMode = .deferred
            key.light?.shadowRadius = 5
            key.position = SCNVector3(-2, 7, 6)
            scene.rootNode.addChildNode(key)
            let ambient = SCNNode()
            ambient.light = SCNLight()
            ambient.light?.type = .ambient
            ambient.light?.intensity = 420
            ambient.light?.color = UIColor(red: 0.85, green: 0.84, blue: 0.82, alpha: 1)
            scene.rootNode.addChildNode(ambient)
            view.scene = scene
            view.pointOfView = camera
            cameraPosition()
        }
        func cameraPosition() {
            SCNTransaction.begin()
            SCNTransaction.animationDuration = 0.5
            let aspect = max(0.4, Float((view?.bounds.width ?? 390) / max(view?.bounds.height ?? 844, 1)))
            let distance = max(8.7, 3.4 / (tan(Float(49.0 * .pi / 360)) * aspect))
            camera.position = SCNVector3(0, boardY(parent.focusShelf) - 1.1, distance)
            camera.eulerAngles = SCNVector3(-0.035, 0, 0)
            SCNTransaction.commit()
        }

        func addBook(_ book: LibraryBook) {
            let root = SCNNode()
            root.name = book.id.uuidString
            let h = CGFloat(book.height), t = CGFloat(book.thickness), depth: CGFloat = 1.12
            let cover = LibraryMaterials.material(book.material, color: book.color)
            let paper = LibraryMaterials.material("paper", color: "#E9DFC6")
            _ = box(t - 0.045, h - 0.07, depth - 0.055, material: paper, position: .init(0, 0, 0), parent: root, bevel: 0.008)
            // The covers are separate pieces; the right board has a hinge at the spine.
            _ = box(0.025, h, depth, material: cover, position: .init(-Float(t / 2), 0, 0), parent: root, bevel: 0.009)
            let hinge = SCNNode()
            hinge.name = "hinge"
            hinge.position = SCNVector3(Float(t / 2), 0, Float(depth / 2))
            root.addChildNode(hinge)
            let coverNode = box(0.025, h, depth, material: cover, position: .init(0, 0, -Float(depth / 2)), parent: hinge, bevel: 0.009)
            let face = SCNPlane(width: depth, height: h)
            face.firstMaterial?.diffuse.contents = LibraryMaterials.cover(book, spine: false)
            face.firstMaterial?.lightingModel = .physicallyBased
            face.firstMaterial?.roughness.contents = 0.7
            let faceNode = SCNNode(geometry: face)
            faceNode.eulerAngles.y = .pi / 2
            faceNode.position.x = 0.014
            coverNode.addChildNode(faceNode)
            let spine = SCNPlane(width: t, height: h)
            spine.firstMaterial?.diffuse.contents = LibraryMaterials.cover(book, spine: true)
            spine.firstMaterial?.lightingModel = .physicallyBased
            spine.firstMaterial?.roughness.contents = 0.7
            let spineNode = SCNNode(geometry: spine)
            spineNode.position.z = Float(depth / 2) + 0.002
            root.addChildNode(spineNode)
            let height = book.horizontal ? Float(t) : Float(h)
            root.position = SCNVector3(Float(book.x), boardY(book.shelf) + 0.07 + height / 2 + 0.025 + Float(book.elevation), 0.1)
            root.eulerAngles.z = book.horizontal ? .pi / 2 : Float(book.tilt * .pi / 180)
            let shape = SCNPhysicsShape(geometry: SCNBox(width: t + 0.03, height: h, length: depth, chamferRadius: 0), options: nil)
            let body = SCNPhysicsBody(type: .dynamic, shape: shape)
            body.mass = 0.7
            body.friction = 0.8
            body.restitution = 0.04
            body.damping = 0.85
            body.angularDamping = 0.9
            body.velocityFactor = SCNVector3(1, 1, 0)
            body.angularVelocityFactor = SCNVector3(0, 0, 1)
            root.physicsBody = body
            scene.rootNode.addChildNode(root)
        }

        func addObject(_ object: ShelfObject) {
            let root = SCNNode()
            root.name = object.id.uuidString
            let material = LibraryMaterials.material("ceramic", color: object.color)
            if object.kind == "frame" {
                _ = box(0.85, 1.0, 0.12, material: LibraryMaterials.material("wood", color: "#745338"),
                        position: SCNVector3(0, 0.5, 0), parent: root, bevel: 0.025)
                _ = box(0.68, 0.82, 0.02, material: material, position: SCNVector3(0, 0.5, 0.08), parent: root)
            } else if object.kind == "sphere" {
                let sphere = SCNSphere(radius: 0.35)
                sphere.firstMaterial = material
                let node = SCNNode(geometry: sphere)
                node.position.y = 0.35
                root.addChildNode(node)
            } else {
                let pot = SCNCone(topRadius: 0.26, bottomRadius: 0.18, height: 0.55)
                pot.firstMaterial = material
                let node = SCNNode(geometry: pot)
                node.position.y = 0.275
                root.addChildNode(node)
                if object.kind == "plant" {
                    for i in 0..<7 {
                        let leaf = SCNSphere(radius: 0.22)
                        leaf.firstMaterial = LibraryMaterials.material("leaf", color: "#38543A")
                        let node = SCNNode(geometry: leaf)
                        let angle = Double(i) * 2.4
                        node.scale = SCNVector3(0.5, 1.6, 0.3)
                        node.position = SCNVector3(Float(sin(angle) * 0.2), 0.65 + Float(i % 3) * 0.11, Float(cos(angle) * 0.15))
                        node.eulerAngles.z = Float(sin(angle) * 0.7)
                        root.addChildNode(node)
                    }
                } else {
                    let neck = SCNCylinder(radius: 0.12, height: 0.38)
                    neck.firstMaterial = material
                    let node = SCNNode(geometry: neck)
                    node.position.y = 0.66
                    root.addChildNode(node)
                }
            }
            root.scale = SCNVector3(Float(object.scale), Float(object.scale), Float(object.scale))
            root.position = SCNVector3(Float(object.x), boardY(object.shelf) + 0.075, 0.25)
            root.physicsBody = SCNPhysicsBody(type: .static, shape: SCNPhysicsShape(node: root, options: nil))
            scene.rootNode.addChildNode(root)
        }

        func hit(_ point: CGPoint) -> SCNNode? {
            guard let view else { return nil }
            for result in view.hitTest(point, options: nil) {
                var node: SCNNode? = result.node
                while let candidate = node {
                    if let name = candidate.name, UUID(uuidString: name) != nil { return candidate }
                    node = candidate.parent
                }
            }
            return nil
        }
        @objc func hold(_ gesture: UILongPressGestureRecognizer) {
            guard !animating, gesture.state == .began, let name = hit(gesture.location(in: view))?.name,
                  let id = UUID(uuidString: name) else { return }
            parent.onInspect(id)
        }
        @objc func tap(_ gesture: UITapGestureRecognizer) {
            guard !animating, let node = hit(gesture.location(in: view)),
                  let name = node.name, let id = UUID(uuidString: name) else { return }
            if parent.arranging || parent.state.objects.contains(where: { $0.id == id }) { parent.onInspect(id) }
            else { extract(node, id: id) }
        }
        @objc func pan(_ gesture: UIPanGestureRecognizer) {
            guard let view, !animating else { return }
            let translation = gesture.translation(in: view)
            if gesture.state == .began {
                active = hit(gesture.location(in: view))
                if let active {
                    if !parent.arranging, let name = active.name, let id = UUID(uuidString: name),
                       parent.state.objects.contains(where: { $0.id == id }) {
                        self.active = nil
                        return
                    }
                    origin = active.presentation.position
                    active.position = origin
                    active.physicsBody?.type = .kinematic
                }
                pulling = false
                selectedShelf = parent.focusShelf
            }
            guard let active else { return }
            if gesture.state == .changed {
                if parent.arranging {
                    let units = Float(2 * tan(49.0 * .pi / 360)) * camera.position.z / Float(max(view.bounds.height, 1))
                    active.position.x = min(2.65, max(-2.65, origin.x + Float(translation.x) * units))
                    active.position.y = origin.y - Float(translation.y) * units
                    let base = active.position.y - 0.7
                    selectedShelf = (0..<parent.state.shelves).min { abs(boardY($0) - base) < abs(boardY($1) - base) } ?? 0
                } else {
                    let progress = min(1, max(0, -translation.y / 130))
                    active.position.z = origin.z + Float(progress) * 2.7
                    active.eulerAngles.y = -Float(progress) * 0.35
                    pulling = progress > 0.48
                }
            }
            if gesture.state == .ended || gesture.state == .cancelled {
                self.active = nil
                guard let name = active.name, let id = UUID(uuidString: name) else { return }
                if parent.arranging && gesture.state == .ended {
                    let book = parent.state.books.first { $0.id == id }
                    let halfHeight = book.map { Float($0.horizontal ? $0.thickness : $0.height) / 2 } ?? 0
                    let elevation = book == nil ? 0 : min(1.8, max(0, Double(active.position.y - boardY(selectedShelf) - 0.095 - halfHeight)))
                    parent.onMove(id, selectedShelf, Double(active.position.x), elevation)
                } else if pulling && gesture.state == .ended && parent.state.books.contains(where: { $0.id == id }) {
                    extract(active, id: id)
                } else {
                    active.position = origin
                    active.eulerAngles.y = 0
                    active.physicsBody?.type = .dynamic
                }
            }
        }
        func extract(_ node: SCNNode, id: UUID) {
            guard !animating else { return }
            animating = true
            node.physicsBody = nil
            UIImpactFeedbackGenerator(style: .soft).impactOccurred()
            let target = SCNVector3(0, camera.position.y, camera.position.z - 3.3)
            let move = SCNAction.move(to: target, duration: 0.45)
            move.timingMode = .easeInEaseOut
            let rotate = SCNAction.rotateTo(x: 0, y: -.pi / 2, z: 0, duration: 0.45)
            node.runAction(.sequence([.group([move, rotate]), .wait(duration: 0.12)])) { [weak self, weak node] in
                DispatchQueue.main.async {
                    guard let self, let node else { return }
                    node.childNode(withName: "hinge", recursively: false)?.runAction(.rotateBy(x: 0, y: -2.6, z: 0, duration: 0.4))
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.42) {
                        self.parent.onOpen(id)
                        self.animating = false
                        self.build()
                    }
                }
            }
        }
    }
}
