import SwiftUI
import PhotosUI
import UIKit

struct BookReader: View {
    let bookID: UUID
    @EnvironmentObject private var store: LibraryStore
    @Environment(\.dismiss) private var dismiss
    @State private var pageID: UUID?
    @State private var customizing = false
    @State private var indexOpen = false
    @State private var deletePage = false

    private var book: LibraryBook? { store.book(bookID) }
    private var index: Int { book?.pages.firstIndex(where: { $0.id == pageID }) ?? 0 }

    var body: some View {
        NavigationStack {
            ZStack {
                Color(uiColor: UIColor(hex: "#382B22")).ignoresSafeArea()
                if let book {
                    PageCurl(bookID: bookID, store: store, pageID: $pageID)
                        .padding(.horizontal, 8).padding(.vertical, 8)
                        .shadow(color: .black.opacity(0.5), radius: 18, x: 0, y: 9)
                        .safeAreaInset(edge: .bottom) {
                            HStack {
                                Button { move(-1) } label: { Image(systemName: "chevron.left") }
                                    .disabled(index == 0)
                                Spacer()
                                Button { indexOpen = true } label: {
                                    Text("Página \(index + 1) de \(book.pages.count)")
                                        .font(.system(.subheadline, design: .serif))
                                }
                                Spacer()
                                Button { move(1) } label: { Image(systemName: "chevron.right") }
                                    .disabled(index >= book.pages.count - 1)
                            }
                            .padding(16).background(.regularMaterial)
                        }
                }
            }
            .navigationTitle(book?.title ?? "Libro")
            .navigationBarTitleDisplayMode(.inline)
            .toolbarBackground(.regularMaterial, for: .navigationBar)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Guardar en estante") { dismiss() }.font(.caption) }
                ToolbarItem(placement: .primaryAction) {
                    Menu {
                        Button("Nueva página", systemImage: "doc.badge.plus") {
                            guard var book else { return }
                            let page = BookPage()
                            book.pages.insert(page, at: min(index + 1, book.pages.count))
                            store.update(book)
                            pageID = page.id
                        }
                        Button("Índice", systemImage: "list.bullet") { indexOpen = true }
                        Button("Encuadernación", systemImage: "book.closed") { customizing = true }
                        Button("Borrar página", systemImage: "trash", role: .destructive) { deletePage = true }
                            .disabled((book?.pages.count ?? 0) < 2)
                    } label: { Image(systemName: "ellipsis.circle") }
                }
            }
            .onAppear { pageID = book?.pages.first?.id }
            .sheet(isPresented: $customizing) { BookCustomizer(bookID: bookID).environmentObject(store) }
            .sheet(isPresented: $indexOpen) {
                NavigationStack {
                    List {
                        if let book {
                            ForEach(Array(book.pages.enumerated()), id: \.element.id) { pair in
                                Button {
                                    pageID = pair.element.id
                                    indexOpen = false
                                } label: {
                                    HStack {
                                        Text("\(pair.offset + 1)").foregroundStyle(.secondary).frame(width: 26)
                                        Text(pair.element.title.isEmpty ? "Sin título" : pair.element.title)
                                            .font(.system(.body, design: .serif))
                                    }
                                }
                            }
                            .onMove { source, destination in
                                var changed = book
                                changed.pages.move(fromOffsets: source, toOffset: destination)
                                store.update(changed)
                            }
                        }
                    }
                    .navigationTitle("Páginas")
                    .toolbar { EditButton() }
                }.presentationDetents([.medium, .large])
            }
            .confirmationDialog("¿Borrar esta página?", isPresented: $deletePage, titleVisibility: .visible) {
                Button("Borrar página", role: .destructive) {
                    guard var book, book.pages.count > 1 else { return }
                    let previous = index
                    book.pages.remove(at: previous)
                    pageID = book.pages[min(previous, book.pages.count - 1)].id
                    store.update(book)
                }
            }
            .alert("Biblioteca", isPresented: Binding(get: { store.error != nil }, set: { if !$0 { store.error = nil } })) {
                Button("Aceptar") { store.error = nil }
            } message: { Text(store.error ?? "") }
        }
        .onChange(of: store.state.books.contains(where: { $0.id == bookID })) { _, exists in
            if !exists { dismiss() }
        }
    }

    private func move(_ delta: Int) {
        guard let book else { return }
        pageID = book.pages[min(max(0, index + delta), book.pages.count - 1)].id
    }
}

final class PageHost: UIHostingController<PageCanvas> {
    let pageID: UUID
    init(bookID: UUID, pageID: UUID, store: LibraryStore) {
        self.pageID = pageID
        super.init(rootView: PageCanvas(bookID: bookID, pageID: pageID, store: store))
        view.backgroundColor = .clear
    }
    @available(*, unavailable)
    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }
}

struct PageCurl: UIViewControllerRepresentable {
    let bookID: UUID
    @ObservedObject var store: LibraryStore
    @Binding var pageID: UUID?
    func makeCoordinator() -> Coordinator { Coordinator(self) }
    func makeUIViewController(context: Context) -> UIPageViewController {
        let controller = UIPageViewController(transitionStyle: .pageCurl, navigationOrientation: .horizontal,
                                              options: [.spineLocation: UIPageViewController.SpineLocation.min.rawValue])
        controller.isDoubleSided = false
        controller.dataSource = context.coordinator
        controller.delegate = context.coordinator
        if let first = pageID ?? store.book(bookID)?.pages.first?.id {
            controller.setViewControllers([context.coordinator.host(first)], direction: .forward, animated: false)
        }
        return controller
    }
    func updateUIViewController(_ controller: UIPageViewController, context: Context) {
        let coordinator = context.coordinator
        coordinator.parent = self
        guard !coordinator.transitioning, let id = pageID,
              (controller.viewControllers?.first as? PageHost)?.pageID != id else { return }
        let current = (controller.viewControllers?.first as? PageHost)?.pageID
        let pages = store.book(bookID)?.pages ?? []
        let before = pages.firstIndex { $0.id == current } ?? 0
        let after = pages.firstIndex { $0.id == id } ?? 0
        controller.setViewControllers([coordinator.host(id)], direction: after >= before ? .forward : .reverse, animated: false)
    }
    @MainActor final class Coordinator: NSObject, UIPageViewControllerDataSource, UIPageViewControllerDelegate {
        var parent: PageCurl
        var transitioning = false
        init(_ parent: PageCurl) { self.parent = parent }
        func host(_ id: UUID) -> PageHost { PageHost(bookID: parent.bookID, pageID: id, store: parent.store) }
        func adjacent(_ controller: UIViewController, delta: Int) -> UIViewController? {
            guard let current = controller as? PageHost, let pages = parent.store.book(parent.bookID)?.pages,
                  let index = pages.firstIndex(where: { $0.id == current.pageID }),
                  pages.indices.contains(index + delta) else { return nil }
            return host(pages[index + delta].id)
        }
        func pageViewController(_ pageViewController: UIPageViewController, viewControllerBefore viewController: UIViewController) -> UIViewController? {
            adjacent(viewController, delta: -1)
        }
        func pageViewController(_ pageViewController: UIPageViewController, viewControllerAfter viewController: UIViewController) -> UIViewController? {
            adjacent(viewController, delta: 1)
        }
        func pageViewController(_ pageViewController: UIPageViewController, willTransitionTo pendingViewControllers: [UIViewController]) {
            transitioning = true
            pageViewController.view.endEditing(true)
        }
        func pageViewController(_ pageViewController: UIPageViewController, didFinishAnimating finished: Bool,
                                previousViewControllers: [UIViewController], transitionCompleted completed: Bool) {
            transitioning = false
            if completed, let current = pageViewController.viewControllers?.first as? PageHost { parent.pageID = current.pageID }
        }
    }
}

struct PageCanvas: View {
    let bookID: UUID
    let pageID: UUID
    @ObservedObject var store: LibraryStore
    @State private var photo: PhotosPickerItem?
    @State private var selectedObject: UUID?
    @State private var loadingPhoto = false
    @State private var decorations = false
    @FocusState private var writing: Bool
    private var page: BookPage? { store.book(bookID)?.pages.first { $0.id == pageID } }
    private var paperColor: String {
        switch page?.paper {
        case "white": return "#FAF9F3"
        case "blue": return "#E4ECED"
        case "rose": return "#EFE1DC"
        default: return "#F2E8D2"
        }
    }

    var body: some View {
        if let page {
            GeometryReader { geometry in
                ZStack(alignment: .topLeading) {
                    Image(uiImage: LibraryMaterials.texture("paper", color: paperColor))
                        .resizable().allowsHitTesting(false)
                    LinearGradient(colors: [.black.opacity(0.19), .clear, .clear, .black.opacity(0.04)],
                                   startPoint: .leading, endPoint: .trailing).allowsHitTesting(false)
                    VStack(alignment: .leading, spacing: 10) {
                        HStack {
                            Text(page.date, style: .date).font(.system(size: 12, design: .serif)).foregroundStyle(.secondary)
                            Spacer()
                            Menu {
                                Picker("Papel", selection: binding(\.paper)) {
                                    Text("Marfil").tag("cream"); Text("Blanco").tag("white")
                                    Text("Azul suave").tag("blue"); Text("Rosa antiguo").tag("rose")
                                }
                                ColorPicker("Tinta", selection: Binding(
                                    get: { Color(uiColor: UIColor(hex: page.ink)) },
                                    set: { color in modify { $0.ink = UIColor(color).hex } }), supportsOpacity: false)
                                DatePicker("Fecha", selection: binding(\.date), displayedComponents: .date)
                            } label: { Image(systemName: "paintpalette").foregroundStyle(.brown) }
                        }
                        TextField("Título de la página", text: binding(\.title), axis: .vertical)
                            .font(.system(size: 27, design: .serif)).foregroundStyle(Color(uiColor: UIColor(hex: page.ink)))
                        Rectangle().fill(.brown.opacity(0.2)).frame(height: 1)
                        TextEditor(text: binding(\.text))
                            .font(.system(size: 18, design: .serif))
                            .foregroundStyle(Color(uiColor: UIColor(hex: page.ink)))
                            .scrollContentBackground(.hidden)
                            .focused($writing)
                            .padding(.horizontal, -5)
                            .accessibilityLabel("Texto de la página")
                        Spacer(minLength: 0)
                    }
                    .padding(.horizontal, 26).padding(.top, 24).padding(.bottom, 56)
                    ForEach(page.objects) { object in
                        CollagePiece(object: object, bounds: geometry.size, selected: selectedObject == object.id,
                                     onSelect: { selectedObject = object.id; writing = false },
                                     onMove: { x, y in changeObject(object.id) { $0.x = x; $0.y = y } })
                    }
                    VStack {
                        Spacer()
                        HStack(spacing: 18) {
                            PhotosPicker(selection: $photo, matching: .images) {
                                Image(systemName: loadingPhoto ? "hourglass" : "photo.badge.plus")
                            }.disabled(loadingPhoto)
                            Button { decorations = true; writing = false } label: { Image(systemName: "sparkles") }
                            Spacer()
                            if selectedObject != nil {
                                Button { selectedObject = nil } label: { Image(systemName: "checkmark") }
                            } else if writing {
                                Button("Listo") { writing = false }.font(.caption)
                            }
                        }
                        .foregroundStyle(.brown).padding(.horizontal, 24).padding(.vertical, 13)
                        .background(.ultraThinMaterial)
                    }
                }
                .clipped()
                .overlay(alignment: .bottom) {
                    if let id = selectedObject, let object = page.objects.first(where: { $0.id == id }) {
                        VStack(spacing: 6) {
                            HStack {
                                Text("Tamaño").font(.caption).frame(width: 60)
                                Slider(value: Binding(get: { object.width }, set: { value in changeObject(id) { $0.width = value } }), in: 0.15...0.9)
                            }
                            HStack {
                                Text("Giro").font(.caption).frame(width: 60)
                                Slider(value: Binding(get: { object.rotation }, set: { value in changeObject(id) { $0.rotation = value } }), in: -180...180)
                                Button(role: .destructive) {
                                    modify { $0.objects.removeAll { $0.id == id } }
                                    selectedObject = nil
                                } label: { Image(systemName: "trash") }
                            }
                        }
                        .padding(12).background(.regularMaterial, in: RoundedRectangle(cornerRadius: 12))
                        .padding(.horizontal, 12).padding(.bottom, 55)
                    }
                }
            }
            .onChange(of: photo) { _, item in
                guard let item else { return }
                loadingPhoto = true
                Task { @MainActor in
                    defer { loadingPhoto = false }
                    do {
                        guard let data = try await item.loadTransferable(type: Data.self) else { throw CocoaError(.fileReadUnknown) }
                        var object = PageObject()
                        object.image = try LibraryStore.photo(data)
                        modify { $0.objects.append(object) }
                        selectedObject = object.id
                        writing = false
                    } catch { store.error = "No se pudo cargar la fotografía." }
                    photo = nil
                }
            }
            .confirmationDialog("Decorar página", isPresented: $decorations, titleVisibility: .visible) {
                ForEach(["✦", "✿", "♡", "❧", "★", "☾"], id: \.self) { symbol in
                    Button(symbol) {
                        var object = PageObject()
                        object.symbol = symbol
                        object.width = 0.2
                        modify { $0.objects.append(object) }
                        selectedObject = object.id
                    }
                }
            }
        }
    }
    private func binding<T>(_ path: WritableKeyPath<BookPage, T>) -> Binding<T> {
        let fallback = page![keyPath: path]
        return Binding(get: { page?[keyPath: path] ?? fallback }, set: { value in modify { $0[keyPath: path] = value } })
    }
    private func modify(_ edit: (inout BookPage) -> Void) {
        guard var changed = page else { return }
        edit(&changed)
        store.updatePage(bookID: bookID, page: changed)
    }
    private func changeObject(_ id: UUID, _ edit: (inout PageObject) -> Void) {
        modify { page in
            guard let index = page.objects.firstIndex(where: { $0.id == id }) else { return }
            edit(&page.objects[index])
        }
    }
}

private struct CollagePiece: View {
    let object: PageObject
    let bounds: CGSize
    let selected: Bool
    let onSelect: () -> Void
    let onMove: (Double, Double) -> Void
    @GestureState private var drag = CGSize.zero
    var body: some View {
        Group {
            if let data = object.image, let image = UIImage(data: data) {
                Image(uiImage: image).resizable().scaledToFit()
                    .padding(5).background(.white)
                    .shadow(color: .black.opacity(0.23), radius: 4, x: 1, y: 3)
            } else {
                Text(object.symbol).font(.system(size: bounds.width * object.width, design: .serif))
                    .foregroundStyle(Color(uiColor: UIColor(hex: "#7F5742")))
            }
        }
        .frame(width: bounds.width * object.width)
        .overlay { if selected { Rectangle().stroke(.brown.opacity(0.6), style: StrokeStyle(lineWidth: 1, dash: [4])) } }
        .rotationEffect(.degrees(object.rotation))
        .position(x: bounds.width * object.x + drag.width, y: bounds.height * object.y + drag.height)
        .onTapGesture(perform: onSelect)
        .gesture(DragGesture(minimumDistance: 5)
            .updating($drag) { value, state, _ in state = value.translation }
            .onChanged { _ in if !selected { onSelect() } }
            .onEnded { value in
                onMove(min(0.9, max(0.1, object.x + value.translation.width / bounds.width)),
                       min(0.86, max(0.12, object.y + value.translation.height / bounds.height)))
            })
        .accessibilityLabel(object.image == nil ? "Decoración \(object.symbol)" : "Fotografía de la página")
    }
}
