# Carpetas para iOS — Biblioteca 2.0

Aplicación nativa en SwiftUI, UIKit y SceneKit. Requiere iOS 17 o posterior.
Los datos se guardan localmente. Las fotos se copian dentro del respaldo de la biblioteca.

## Compilar desde GitHub usando el ZIP

1. Sube Carpetas-iOS.zip a la raíz de tu repositorio.
2. En GitHub, elige Add file → Create new file.
3. Escribe exactamente .github/workflows/build-ios.yml como nombre del archivo.
4. Pega el contenido de Compilar-Carpetas-iOS.yml que acompaña la entrega y guarda con Commit changes.
5. Abre Actions → Compilar Carpetas iOS → Run workflow.
6. Al terminar, descarga Carpetas-iOS en Artifacts y extrae Carpetas.ipa.
7. Instala la IPA con SideStore, usando tu configuración de firma.

El workflow también está dentro del ZIP. GitHub ejecuta los workflows que están
en .github/workflows del repositorio. El ZIP por sí solo necesita el paso 2.
La IPA que produce el workflow se entrega sin firma. SideStore aplica la firma al instalar.
Para Xcode en un Mac, instala XcodeGen, ejecuta xcodegen generate y abre Carpetas.xcodeproj.
El identificador del proyecto es pe.eduardo.carpetas. Mantén ese identificador para las actualizaciones de iOS.

## Biblioteca

- Crea un libro desde el menú de la esquina superior.
- Mantén pulsado un libro para editar su portada y lomo, colores, fotografía,
  grabado, material, tamaño, inclinación y estante.
- Tira hacia arriba en la pantalla para sacar un libro hacia la cámara y abrirlo.
  También puedes tocarlo para realizar la misma animación.
- La mano activa la colocación. Arrastra un libro a otra posición o estante visible.
  Usa las flechas inferiores para recorrer el librero.
- Hay gravedad y colisiones en el plano del estante. El movimiento hacia la cámara
  y la apertura de la cubierta siguen una animación guiada. La posición elegida
  queda guardada. El pequeño asentamiento físico se calcula al mostrar la escena.
- Los libros pueden colocarse de pie, inclinados, acostados o apilados.
  Usa Altura en la pila o arrastra sobre otros libros para apilar. Las cubiertas tienen
  bisagra separada. Los cantos, el cuero, el lino, el papel y la madera usan texturas procedurales.
- Añade jarrones, plantas, marcos o esferas y cambia su color, tamaño y posición.

## Páginas

- Cada libro comienza con una página. El menú permite añadir páginas y abrir el índice.
- El índice permite reordenar las páginas con Editar.
- Escribe título y texto, cambia fecha, papel y tinta.
- Añade fotos o decoraciones. Tócalas para cambiar tamaño y giro o borrarlas.
  Arrástralas para situarlas sobre el papel.
- Cambia de página con las flechas o con el gesto en el borde de la hoja.
- Los cambios se guardan al editar. Si falla la escritura, aparece un aviso.

## Trasladar los archivos de Android

En Carpetas para Android usa Vista → Guardar respaldo. Pasa ese JSON al iPhone.
En la biblioteca de iOS abre el menú → Importar respaldo y selecciona el JSON.
Cada carpeta se convierte en libro y cada archivo en página, con su título, texto,
fecha y fotos. La restauración sustituye la biblioteca actual, previa confirmación.
Los 36 registros de Celulares se trasladan si ya están en el respaldo de Android.
Exporta primero tu biblioteca de iOS si ya contiene páginas que deseas conservar.

## Estado de verificación

El paquete se preparó en Linux. Se revisaron la sintaxis Swift, la estructura,
los recursos y el workflow. La compilación con los SDK de Apple y la prueba
en iPhone quedan pendientes de ejecutar el workflow. El comportamiento del
gesto, los materiales y el rendimiento deben comprobarse en un dispositivo iOS.
